# Memory Bank CLI Commands - Design & Implementation Guide

## Overview
This document outlines optional CLI commands that can be added to enhance memory bank operations in savant-context.

---

## Command Hierarchy

The memory bank CLI commands follow the pattern:
```
savant-context memory [SUBCOMMAND] [OPTIONS]
```

### Proposed Command Structure

```
memory
├── search <query>          - Search memory bank documents
├── list [--repo REPO]      - List all memory bank files
├── read <uri>              - Read a memory bank document
├── stats [--repo REPO]     - Show memory bank statistics
├── validate [--repo REPO]  - Validate memory bank integrity
├── export <path>           - Export memory bank to file
└── import <path>           - Import memory bank from file
```

---

## Detailed Command Specifications

### 1. `memory search` - Search Memory Bank
**Purpose**: Full-text search of memory bank documents only

**Usage**:
```bash
savant-context memory search "architecture patterns"
savant-context memory search "API design" --repo my-project --limit 5
savant-context memory search "patterns" --format json
```

**Options**:
- `<query>` (required): Search query
- `--repo REPO`: Filter by repository name
- `--limit N`: Maximum results (1-100, default 20)
- `--format FORMAT`: Output format (table, json, text; default: table)
- `--highlight`: Highlight search terms in results

**Output Example (table)**:
```
MEMORY BANK SEARCH RESULTS
─────────────────────────────────────────────────────────────
Repo         File                      Chunks  Rank   Preview
─────────────────────────────────────────────────────────────
my-project   memory_bank/architecture  12      1.0    "## Architecture Patterns\n\nOur system uses..."
my-project   memory_bank/api-design    8       0.95   "# API Design Guidelines\n\nRESTful endpoints..."
my-project   memory_bank/patterns      5       0.89   "# Design Patterns\n\nCommon patterns we use..."
```

**Implementation**:
```python
@main.group()
def memory() -> None:
    """Memory bank management commands."""
    pass

@memory.command(name="search")
@click.argument("query")
@click.option("--repo", default=None, help="Filter by repository")
@click.option("--limit", default=20, type=int, help="Maximum results")
@click.option("--format", type=click.Choice(["table", "json", "text"]), default="table")
@click.option("--highlight", is_flag=True, help="Highlight search terms")
def memory_search(query: str, repo: Optional[str], limit: int, format: str, highlight: bool) -> None:
    """Search memory bank documents."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()
    try:
        handler = ToolHandler(db_client)
        result = handler.memory_search(query=query, repo=repo, limit=limit)

        if format == "json":
            import json
            click.echo(json.dumps(result, indent=2, default=str))
        elif format == "table":
            _display_memory_search_table(result, highlight)
        else:
            _display_memory_search_text(result)
    finally:
        db_client.close()
```

---

### 2. `memory list` - List Memory Bank Files
**Purpose**: Browse all indexed memory bank documents

**Usage**:
```bash
savant-context memory list
savant-context memory list --repo my-project
savant-context memory list --sort updated
savant-context memory list --format json
```

**Options**:
- `--repo REPO`: Filter by repository
- `--sort FIELD`: Sort by field (name, size, created, updated; default: name)
- `--format FORMAT`: Output format (table, json, tree; default: table)
- `--show-chunks`: Include chunk count

**Output Example (table)**:
```
MEMORY BANK RESOURCES
────────────────────────────────────────────────────────────────
Repo         File Path                    Size    Chunks  Updated
────────────────────────────────────────────────────────────────
my-project   memory_bank/architecture.md  12 KB   15      2025-12-19
my-project   memory_bank/api-design.md    8 KB    10      2025-12-19
my-project   memory_bank/patterns.md      5 KB    7       2025-12-18
```

**Output Example (tree)**:
```
MEMORY BANK RESOURCES
────────────────────────────────────────────────────────────────
my-project/
  └── memory_bank/
      ├── architecture.md (12 KB, 15 chunks)
      ├── api-design.md (8 KB, 10 chunks)
      └── patterns.md (5 KB, 7 chunks)
```

---

### 3. `memory read` - Read Memory Bank Document
**Purpose**: Display full content of a memory bank document

**Usage**:
```bash
savant-context memory read "memory_bank/architecture.md"
savant-context memory read "my-project:memory_bank/api-design.md"
savant-context memory read memory_bank/patterns.md --less
savant-context memory read memory_bank/api-design.md --raw
```

**Options**:
- `<uri>` (required): Resource URI (path or "repo:path")
- `--raw`: Output raw markdown without formatting
- `--less`: Pipe to `less` pager
- `--format FORMAT`: Output format (markdown, text, html; default: markdown)
- `--line-numbers`: Show line numbers

**Output Example**:
```markdown
MEMORY BANK DOCUMENT: my-project:memory_bank/architecture.md
──────────────────────────────────────────────────────────────

# System Architecture

## Overview
Our system uses a microservices architecture with the following components:

### Core Services
- API Gateway (Node.js + Express)
- Auth Service (Python + FastAPI)
- Database Service (PostgreSQL)
- Cache Service (Redis)

## Data Flow
...
```

---

### 4. `memory stats` - Memory Bank Statistics
**Purpose**: Show statistics about memory bank documents

**Usage**:
```bash
savant-context memory stats
savant-context memory stats --repo my-project
savant-context memory stats --format json
```

**Options**:
- `--repo REPO`: Filter by repository
- `--format FORMAT`: Output format (table, json; default: table)
- `--detail`: Show detailed breakdown

**Output Example**:
```
MEMORY BANK STATISTICS
─────────────────────────────────────────────────────────────
Total Repositories:     3
Total Memory Bank Files: 42
Total Chunks Indexed:   512
Total Size:             245 KB

BY REPOSITORY:
────────────────────────────────────────────────────────────
Repo           Files   Chunks  Size    Created
────────────────────────────────────────────────────────────
my-project     15      180     95 KB   2025-12-01
other-project  18      200     110 KB  2025-12-05
api-service    9       132     40 KB   2025-12-10

TOP FILES BY SIZE:
────────────────────────────────────────────────────────────
File                              Size    Chunks
────────────────────────────────────────────────────────────
my-project:memory_bank/api.md     18 KB   25
other-project:memory_bank/arch.md 15 KB   20
api-service:memory_bank/design.md 12 KB   16
```

---

### 5. `memory validate` - Validate Memory Bank Integrity
**Purpose**: Check for orphaned chunks, consistency issues

**Usage**:
```bash
savant-context memory validate
savant-context memory validate --repo my-project --fix
savant-context memory validate --format json
```

**Options**:
- `--repo REPO`: Validate specific repository
- `--fix`: Attempt to fix issues found
- `--format FORMAT`: Output format (text, json; default: text)
- `--strict`: Report warnings as errors

**Output Example**:
```
MEMORY BANK VALIDATION
────────────────────────────────────────────────────────────
Status: ✓ PASSED (3 files validated)

Files Validated:     3
Chunks Validated:    42
Orphans Found:       0
Consistency Errors:  0
Missing Content:     0

Status: ✓ HEALTHY
```

---

### 6. `memory export` - Export Memory Bank
**Purpose**: Export memory bank to markdown files

**Usage**:
```bash
savant-context memory export ./memory_backup
savant-context memory export ./memory_backup --repo my-project
savant-context memory export ./memory_backup --format zip
savant-context memory export ./memory_backup --format tar.gz
```

**Options**:
- `<path>` (required): Export destination directory
- `--repo REPO`: Export specific repository only
- `--format FORMAT`: Export format (dir, zip, tar.gz; default: dir)
- `--include-metadata`: Include index metadata
- `--overwrite`: Overwrite existing files

**Output Example**:
```
EXPORTING MEMORY BANK
────────────────────────────────────────────────────────────
Destination: ./memory_backup
Format: directory
Compression: none

Exporting my-project...
  ✓ memory_bank/architecture.md (12 KB)
  ✓ memory_bank/api-design.md (8 KB)
  ✓ memory_bank/patterns.md (5 KB)

Total Files: 3
Total Size: 25 KB
Time: 0.25s

✓ Export complete to ./memory_backup
```

---

### 7. `memory import` - Import Memory Bank
**Purpose**: Import memory bank from exported files

**Usage**:
```bash
savant-context memory import ./memory_backup
savant-context memory import ./memory_backup --repo new-project
savant-context memory import memory_backup.zip --repo backup
```

**Options**:
- `<path>` (required): Import source (directory or archive)
- `--repo REPO`: Target repository name
- `--merge`: Merge with existing (default: replace)
- `--validate`: Validate before import

**Output Example**:
```
IMPORTING MEMORY BANK
────────────────────────────────────────────────────────────
Source: ./memory_backup
Target Repo: my-project
Mode: merge

Found 3 files to import:
  ✓ architecture.md
  ✓ api-design.md
  ✓ patterns.md

Indexing...
  ✓ memory_bank/architecture.md (12 KB → 15 chunks)
  ✓ memory_bank/api-design.md (8 KB → 10 chunks)
  ✓ memory_bank/patterns.md (5 KB → 7 chunks)

Total Files: 3
Total Chunks: 32
Time: 0.45s

✓ Import complete
```

---

## Implementation Considerations

### 1. Output Formatting
- **Table**: Use `click.formatting.HelpFormatter` or `tabulate` library
- **JSON**: Use `json.dumps()` with proper serialization
- **Tree**: Custom ASCII tree implementation

### 2. Pagination
- Large result sets should support pagination
- Option: `--page N --per-page M`

### 3. Piping Support
- Output should be pipeable to other commands
- Use stderr for progress/debug info, stdout for results

### 4. Error Handling
- Clear error messages for missing URIs
- Suggestions for common mistakes

### 5. Performance
- Cache repo stats
- Lazy-load large documents
- Stream export for large datasets

---

## File Structure for Implementation

```python
# savant_context/cli/memory.py (NEW FILE)

import click
from typing import Optional
from ..mcp.tools import ToolHandler
from ..db import DatabaseClient

@click.group(name="memory")
def memory_group():
    """Memory bank management commands."""
    pass

@memory_group.command(name="search")
def cmd_memory_search(...):
    # Implementation...

@memory_group.command(name="list")
def cmd_memory_list(...):
    # Implementation...

# ... more commands

# Then in cli.py, add:
# from .cli.memory import memory_group
# main.add_command(memory_group)
```

---

## Example Workflows

### Workflow 1: Finding Documentation
```bash
# Search for API information
savant-context memory search "authentication API"

# List all API-related docs
savant-context memory list --sort updated

# Read specific document
savant-context memory read "memory_bank/api-design.md" --less
```

### Workflow 2: Backing Up Memory Bank
```bash
# Export to directory
savant-context memory export ~/backups/memory_bank_2025_12_19

# Or export as ZIP
savant-context memory export memory_bank.zip --format zip

# Later, restore from backup
savant-context memory import memory_bank.zip --merge
```

### Workflow 3: Validating Installation
```bash
# Check memory bank health
savant-context memory validate

# Get detailed stats
savant-context memory stats --detail

# Look for specific documentation
savant-context memory search "architecture"
```

---

## Integration with Existing CLI

These commands integrate seamlessly with existing commands:

```bash
# Index a repo
savant-context index repo /path/to/repo

# Then use memory bank commands
savant-context memory list
savant-context memory search "architecture"
savant-context memory stats
```

---

## Future Enhancements

1. **Watch Mode**: Auto-import new memory bank files
   ```bash
   savant-context memory watch /path/to/repo
   ```

2. **Sync**: Sync memory bank with remote source
   ```bash
   savant-context memory sync --remote github.com/org/repo
   ```

3. **Diff**: Show changes between versions
   ```bash
   savant-context memory diff version1 version2
   ```

4. **Notifications**: Alert on memory bank updates
   ```bash
   savant-context memory notify --on-update
   ```

---

## Priority Order for Implementation

**High Priority** (Most Useful):
1. `memory search` - Core functionality
2. `memory list` - Browse capability
3. `memory read` - Access documents

**Medium Priority** (Nice to Have):
4. `memory stats` - Understanding usage
5. `memory export` - Backup capability

**Low Priority** (Nice to Future):
6. `memory validate` - Maintenance
7. `memory import` - Restore capability

---

## Testing Strategy

```bash
# After implementation, test with:

# 1. Basic operations
savant-context memory list
savant-context memory search "test"

# 2. Format options
savant-context memory list --format json
savant-context memory stats --format json

# 3. Filtering
savant-context memory list --repo test-repo
savant-context memory search "query" --repo test-repo

# 4. Piping
savant-context memory list | grep architecture
savant-context memory search "api" | jq '.results[0]'

# 5. Error cases
savant-context memory read "nonexistent.md"
savant-context memory list --repo nonexistent-repo
```

---

## Conclusion

These memory bank CLI commands provide intuitive access to memory bank functionality while maintaining consistency with the existing CLI structure. They can be implemented incrementally, starting with the high-priority commands (search, list, read).
