# Setting Up Private Code Repo with Public Homebrew Tap

## Architecture Overview

```
Public Homebrew Tap Repo          Private Code Repo
(homebrew-savant)                 (context - private)
├── Formula/                       ├── savant_context/
│   └── savant-context.rb         ├── setup.py
├── README.md                      ├── requirements.txt
└── LICENSE                        └── ... (all source code)

User runs: brew tap ashabbir/savant
           brew install savant-context
                ↓
Homebrew clones tap repo (public)
Reads formula → downloads release from private repo
(requires GitHub token for private downloads)
```

## Step 1: Make Your Code Repo Private

```bash
# Go to GitHub.com → ashabbir/context → Settings
# Scroll to "Danger Zone" → Change repository visibility to Private
```

Or via GitHub CLI:
```bash
gh repo edit ashabbir/context --visibility private
```

## Step 2: Create GitHub Personal Access Token

If you don't already have one:

1. Go to: https://github.com/settings/tokens/new
2. Select scopes:
   - ✅ `repo` (full control of private repositories)
   - ✅ `workflow` (for GitHub Actions)
3. Copy the token and save it securely
4. Never commit it to any repo

## Step 3: Create the Homebrew Tap Repository

### Create new empty repository on GitHub
- Name: `homebrew-savant`
- Description: "Homebrew tap for Savant Context"
- Visibility: **PUBLIC**
- Do NOT initialize with README

### Clone locally
```bash
mkdir ~/homebrew-repos
cd ~/homebrew-repos
git clone git@github.com:ashabbir/homebrew-savant.git
cd homebrew-savant
```

## Step 4: Set Up Tap Structure

```bash
# Create the required directory structure
mkdir -p Formula

# Create the formula
touch Formula/savant-context.rb
```

### Update the formula for private repo

Edit `Formula/savant-context.rb`:

```ruby
class SavantContext < Formula
  include Language::Python::Virtualenv

  desc "Context MCP server with PostgreSQL-based code indexer"
  homepage "https://github.com/ashabbir/context"
  url "https://github.com/ashabbir/context/archive/refs/tags/v0.1.0.tar.gz"
  sha256 "a394b46fb57c19705e24239761a3f84804368f524e97437e9a3f59e3f4b917e4"
  license "MIT"

  depends_on "python@3.10"
  depends_on "postgresql@15"

  def install
    virtualenv_install_with_resources
  end

  def post_install
    (var/"savant-context").mkpath
  end

  test do
    system "#{bin}/savant-context", "--version"
  end

  service do
    run [opt_bin/"savant-context", "run"]
    keep_alive true
    environment_variables PATH: std_service_path_env
    log_path var/"log/savant-context.log"
    error_log_path var/"log/savant-context.error.log"
  end
end
```

## Step 5: Create Tap README

Create `README.md` in the tap repo:

```markdown
# Homebrew Tap for Savant Context

Install [Savant Context](https://github.com/ashabbir/context) using Homebrew.

## Installation

```bash
brew tap ashabbir/savant
brew install savant-context
```

## Requirements

- macOS or Linux
- Python 3.10+
- PostgreSQL 15+

## Quick Start

After installation:

```bash
savant-context db setup
savant-context index repo ./path/to/repo
savant-context status
savant-context run
```

## Documentation

See the [main repository](https://github.com/ashabbir/context) for full documentation.

## License

MIT
```

## Step 6: Push the Tap Repository

```bash
# Inside homebrew-savant directory
git add .
git commit -m "Initial Homebrew tap for savant-context"
git push -u origin main
```

## Step 7: Configure Homebrew to Use GitHub Token

Users will need to authenticate to download from your private repo. They can do this by:

### Option A: Via Environment Variable (One-time)
```bash
export HOMEBREW_GITHUB_API_TOKEN=your_github_token
brew tap ashabbir/savant
brew install savant-context
```

### Option B: Via Git Config (Permanent)
```bash
git config --global url."https://<token>@github.com/".insteadOf "https://github.com/"
brew tap ashabbir/savant
brew install savant-context
```

### Option C: Via ~/.netrc (Permanent)
Create `~/.netrc`:
```
machine github.com
login your_username
password your_github_token
```

Then:
```bash
chmod 600 ~/.netrc
brew tap ashabbir/savant
brew install savant-context
```

## Step 8: Test the Installation

### For yourself (with token)
```bash
# Set your token
export HOMEBREW_GITHUB_API_TOKEN=your_token

# Remove old tap
brew untap ashabbir/savant

# Tap and install fresh
brew tap ashabbir/savant
brew install savant-context

# Verify
savant-context --version
savant-context --help
```

## Alternative: Using Release Assets

For a cleaner approach, you can upload the tarball as a GitHub Release asset:

1. Create a release on your private `context` repo
2. Upload `context-0.1.0.tar.gz` as an asset
3. Update formula URL to point to the release asset instead

This requires fewer token permissions.

## Troubleshooting

### "Could not download" error
- **Cause**: Token not configured or expired
- **Fix**: Set `HOMEBREW_GITHUB_API_TOKEN` environment variable

### "Not Found" error
- **Cause**: Private repo URL without authentication
- **Fix**: Make sure token has `repo` scope
- **Verify**: `curl -H "Authorization: token YOUR_TOKEN" https://api.github.com/user`

### Formula not found
- **Cause**: Formula not in `Formula/` directory in tap repo
- **Fix**: Check directory structure and push changes
- **Verify**: `brew tap-info ashabbir/savant`

## What's Public vs Private

| Item | Visibility | Access |
|------|-----------|--------|
| Homebrew tap repo | 🌐 PUBLIC | Anyone can see/clone |
| Formula file | 🌐 PUBLIC | Anyone can read |
| Code repo (context) | 🔒 PRIVATE | Only you/collaborators |
| Release tarball | 🔒 PRIVATE | Only authenticated users |

## Security Notes

- ✅ Keep your GitHub token in `.bashrc` or `.zshrc`, not in files you commit
- ✅ Use a token with minimal required scopes
- ✅ Rotate tokens regularly
- ✅ Never add tokens to environment files that get committed
- ✅ Consider using GitHub's built-in authentication if using GitHub CLI

## Distribution to Team

To share with your team:

```bash
# Team member runs:
export GITHUB_TOKEN=their_token
brew tap ashabbir/savant
brew install savant-context
```

Or use SSH with key-based auth:
```bash
git config --global url."git@github.com:".insteadOf "https://github.com/"
brew tap ashabbir/savant
brew install savant-context
```

## Next Steps

1. Create `homebrew-savant` repository
2. Set up Formula directory with formula file
3. Push to GitHub
4. Configure your token for testing
5. Test installation locally
6. Share installation instructions with users
7. Make the code repo private
