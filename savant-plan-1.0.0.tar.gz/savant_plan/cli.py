"""CLI for savant-plan."""

from __future__ import annotations

import json
import logging
import sys
from typing import Optional

import click

from . import __version__
from .mcp.server import MCPServer

# Configure logging to stderr only (keep stdout MCP-clean)
logging.basicConfig(level=logging.ERROR, format="%(name)s - %(levelname)s - %(message)s", stream=sys.stderr)
logger = logging.getLogger(__name__)


BANNER = """
  ███████╗ █████╗ ██╗   ██╗ █████╗ ███╗   ██╗████████╗
  ██╔════╝██╔══██╗██║   ██║██╔══██╗████╗  ██║╚══██╔══╝
  ███████╗███████║██║   ██║███████║██╔██╗ ██║   ██║   
  ╚════██║██╔══██║╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║   
  ███████║██║  ██║ ╚████╔╝ ██║  ██║██║ ╚████║   ██║   
  ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   

 Savant Plan - MCP Server for Planning Sessions
 By AmdSh
 Project 🅧
 Version: {version}
  Session: ephemeral (in-memory)
  Steps: {steps}

 ═══════════════════════════════════════════════════════════════════════════════
"""


def print_banner(steps: int = 0) -> None:
    click.echo(BANNER.format(version=__version__, steps=steps))


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="savant-plan")
@click.pass_context
def main(ctx) -> None:
    """Savant Plan - Minimal in-memory planning MCP server."""
    pure_output = {"run", "tool"}
    if ctx.invoked_subcommand not in pure_output:
        print_banner(steps=0)
    if ctx.invoked_subcommand is None:
        pass


@main.command()
def run() -> None:
    """Start the MCP server (stdio)."""
    server = MCPServer()
    try:
        server.run()
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show current session step count (ephemeral)."""
    # New server instance has empty plan; this is informational
    click.echo("Session: in-memory (ephemeral)")
    click.echo("Steps: 0")


@main.group()
def tool() -> None:
    """Call MCP tools directly from CLI (JSON output)."""
    pass


@tool.command(name="add_step")
@click.option("--step", type=int, required=True, help="Sequential step number (1..N)")
@click.option("--content", type=str, required=True, help="Step content")
def tool_add_step(step: int, content: str) -> None:
    server = MCPServer()
    # Simulate a single call session
    result = server.tool_handler.add_step(step=step, content=content)
    click.echo(json.dumps(result, indent=2))


@tool.command(name="revise_step")
@click.option("--step", type=int, required=True, help="Existing step number")
@click.option("--content", type=str, required=True, help="Replacement content")
def tool_revise_step(step: int, content: str) -> None:
    server = MCPServer()
    result = server.tool_handler.revise_step(step=step, content=content)
    click.echo(json.dumps(result, indent=2))

