"""MCP tool implementations for Savant Plan."""

from __future__ import annotations

from typing import Any, Dict, List


class ToolHandler:
    def __init__(self, steps: List[Dict[str, Any]]):
        # steps: list of {step:int, content:str}
        self.steps = steps

    def add_step(self, step: Any, content: Any) -> Dict[str, Any]:
        # Validate input
        try:
            step_num = int(step)
        except Exception:
            return {"ok": False, "error": "step must be an integer"}
        text = (content or "").strip()
        if not text:
            return {"ok": False, "error": "content is required"}

        # Enforce sequential rule
        if self.steps:
            last = self.steps[-1]["step"]
            if step_num != last + 1:
                return {"ok": False, "error": f"step must be sequential (expected {last+1})"}
        else:
            if step_num != 1:
                return {"ok": False, "error": "first step must be 1"}

        # Enforce duplicate rejection
        if any(s["step"] == step_num for s in self.steps):
            return {"ok": False, "error": f"step {step_num} already exists"}

        self.steps.append({"step": step_num, "content": text})
        return {"ok": True, "plan": self.steps}

    def revise_step(self, step: Any, content: Any) -> Dict[str, Any]:
        # Validate input
        try:
            step_num = int(step)
        except Exception:
            return {"ok": False, "error": "step must be an integer"}
        text = (content or "").strip()
        if not text:
            return {"ok": False, "error": "content is required"}

        for s in self.steps:
            if s["step"] == step_num:
                s["content"] = text
                return {"ok": True, "plan": self.steps}

        return {"ok": False, "error": f"step {step_num} does not exist"}


def get_tool_definitions() -> List[Dict[str, Any]]:
    return [
        {
            "name": "add_step",
            "description": "Append a sequential plan step (1..N)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "step": {"type": "integer", "minimum": 1, "description": "Sequential step number"},
                    "content": {"type": "string", "description": "Step content"},
                },
                "required": ["step", "content"],
            },
        },
        {
            "name": "revise_step",
            "description": "Revise an existing step's content",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "step": {"type": "integer", "minimum": 1, "description": "Existing step number"},
                    "content": {"type": "string", "description": "Replacement content"},
                },
                "required": ["step", "content"],
            },
        },
    ]

