Savant Plan
===========

Standalone MCP server that lets agents write and revise a plan before execution. In-memory, minimal, and MCP-compliant.

Commands
- `savant-plan run` — start MCP server on stdio
- `savant-plan status` — show current session step count
- `savant-plan tool add_step --step 1 --content "..."` — direct tool call
- `savant-plan tool revise_step --step 1 --content "..."` — direct tool call

MCP Tools
- `add_step(step:int, content:str)` — append a sequential step (1..N)
- `revise_step(step:int, content:str)` — replace content of an existing step

