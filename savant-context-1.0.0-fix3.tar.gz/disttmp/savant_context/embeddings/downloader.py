"""Utilities to fetch a pinned embedding model on demand.

Uses huggingface_hub to snapshot a specific repo + revision to a local folder.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..config import Config


def default_model_dir(base_dir: Optional[Path] = None) -> Path:
    """Return the default on-disk directory for the model.

    The path is ~/.savant/models/<name>/<version> unless a base_dir is provided.
    """
    if base_dir is None:
        base_dir = Path.home() / ".savant" / "models"
    return base_dir / Config.EMBEDDING_MODEL_NAME / Config.EMBEDDING_VERSION


def download_model(
    dest: Optional[Path] = None,
    repo_id: Optional[str] = None,
    revision: Optional[str] = None,
) -> Path:
    """Download the pinned model to dest and return the path.

    - dest: target directory to place files (created if missing)
    - repo_id: HF repo id to snapshot (default from Config)
    - revision: commit hash/tag to pin (default from Config)
    """
    # Defer import so runtime stays offline unless explicitly downloading
    from huggingface_hub import snapshot_download  # type: ignore

    target = dest or default_model_dir()
    target = Path(target)
    target.mkdir(parents=True, exist_ok=True)

    repo = repo_id or Config.EMBEDDING_REPO_ID
    rev = revision or Config.EMBEDDING_REVISION

    snapshot_download(
        repo_id=repo,
        revision=rev,
        local_dir=str(target),
        local_dir_use_symlinks=False,
    )

    return target

