"""CLI for savant-context."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .config import Config
from .db import DatabaseClient, init_schema
from .db.schema import verify_vector_support
from .db.operations import dump_database, restore_database, create_database
from .indexer import Indexer
from .mcp.server import MCPServer
from .embeddings.downloader import download_model, default_model_dir
from .utils.deps import ensure_transformer_deps

# Configure logging to stderr only
# This keeps stdout clean for MCP JSON-RPC compliance in server mode
logging.basicConfig(
    level=logging.ERROR,  # Only show errors by default to keep output clean
    format="%(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# ASCII Art
BANNER = """
  ███████╗ █████╗ ██╗   ██╗ █████╗ ███╗   ██╗████████╗
  ██╔════╝██╔══██╗██║   ██║██╔══██╗████╗  ██║╚══██╔══╝
  ███████╗███████║██║   ██║███████║██╔██╗ ██║   ██║   
  ╚════██║██╔══██║╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║   
  ███████║██║  ██║ ╚████╔╝ ██║  ██║██║ ╚████║   ██║   
  ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   

 Savant Context - MCP Server with Code Indexer
 By AmdSh
 Project 🅧
 Version: {version}
  Model: {model}
  Postgres: {pg}
  pgvector: {pgvector}

 CLI Commands:
   savant-context / savant              Show banner
   savant-context run / savant           Start MCP server
   savant-context db setup              Initialize database
   savant-context db dump <path>        Backup database
   savant-context db restore <path>     Restore database
   savant-context db destroy            Delete database
   savant-context db psql               Open psql shell
   savant-context index repo [path]     Index repository
   savant-context status                Show indexing status
  savant-context readme                Show documentation
  savant-context diagnostics           Show environment diagnostics

 Memory Bank Commands:
   savant-context memory search <q>     Search memory bank documents
   savant-context memory list           List memory bank files
   savant-context memory read <uri>     Read a memory bank document
   savant-context memory stats          Show memory bank statistics
   savant-context memory export <path>  Backup memory bank
   savant-context memory import <path>  Restore memory bank
   savant-context memory validate       Check memory bank integrity

 MCP Tools:
   code_search                Semantic search across indexed code
   memory_bank_search         Search memory bank markdown
   memory_resources_list      List memory bank resources
   memory_resources_read      Read resource by URI
   repos_list                 List repos with README excerpts
   repo_status                Show per-repo index status

 ═══════════════════════════════════════════════════════════════════════════════
"""


def get_db_client() -> DatabaseClient:
    """Get a connected database client."""
    client = DatabaseClient()
    try:
        client.connect()
    except Exception as e:
        click.echo(f"Error: Failed to connect to database: {e}", err=True)
        raise click.Abort()
    return client


def print_banner() -> None:
    """Print the ASCII art banner."""
    model_desc = f"{Config.EMBEDDING_MODEL_NAME} ({Config.EMBEDDING_REPO_ID}@{Config.EMBEDDING_REVISION})"

    # Default DB info if not available
    pg_desc = f"{Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB} (unavailable)"
    vector_desc = "unknown"

    # Best-effort DB inspection; never crash the banner
    try:
        client = DatabaseClient()
        client.connect()
        try:
            row = client.fetch_one("SHOW server_version")
            ver = row.get("server_version") if row else None
            pg_desc = f"{Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB} (v{ver})" if ver else f"{Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB}"

            ext = client.fetch_one("SELECT extversion FROM pg_extension WHERE extname = 'vector'")
            if ext and ext.get("extversion"):
                vector_desc = f"installed (v{ext['extversion']})"
            else:
                vector_desc = "not installed"
        finally:
            client.close()
    except Exception:
        # Keep defaults if DB unreachable
        pass

    click.echo(
        BANNER.format(
            version=__version__,
            model=model_desc,
            pg=pg_desc,
            pgvector=vector_desc,
        )
    )


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="savant-context")
@click.pass_context
def main(ctx) -> None:
    """Savant Context - Code indexer and MCP server."""
    # Skip banner for commands that require clean output
    # 'run': MCP server (must output ONLY JSON-RPC)
    # 'tool': CLI tool calls (must output ONLY JSON)
    pure_output_commands = {"tool", "run"}

    if ctx.invoked_subcommand not in pure_output_commands:
        print_banner()

    if ctx.invoked_subcommand is None:
        # Print banner when no subcommand given
        pass  # Banner already printed


@main.command()
def run() -> None:
    """Start the MCP server."""
    # MCP spec requires ONLY JSON-RPC on stdout, so no startup messages
    # All diagnostic output goes to stderr
    db_client = get_db_client()

    try:
        # Verify schema exists
        if not db_client.table_exists("repos"):
            click.echo("ERROR: Database schema not initialized. Run 'db:setup' first.", err=True)
            db_client.close()
            raise click.Abort()

        # Verify pgvector + embedding schema present
        try:
            verify_vector_support(db_client)
        except Exception as e:
            click.echo(f"ERROR: {e}", err=True)
            db_client.close()
            raise click.Abort()

        # Create and run MCP server
        mcp = MCPServer(db_client)

        try:
            mcp.run()
        except KeyboardInterrupt:
            pass  # Graceful shutdown
        finally:
            db_client.close()

    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        raise click.Abort()


@main.command(name="diagnostics")
def diagnostics() -> None:
    """Show environment diagnostics: model, DB, and vector schema."""
    click.echo("Diagnostics:")
    # Model info
    click.echo("- Model:")
    click.echo(f"  Name: {Config.EMBEDDING_MODEL_NAME}")
    click.echo(f"  Repo: {Config.EMBEDDING_REPO_ID}@{Config.EMBEDDING_REVISION}")
    click.echo(f"  Dim:  {Config.EMBEDDING_DIM}")
    # Resolve model dir as used by the runtime
    if Config.EMBEDDING_MODEL_DIR:
        model_dir = Path(Config.EMBEDDING_MODEL_DIR)
    else:
        model_dir = Path(__file__).parent / "embeddings" / "models" / Config.EMBEDDING_MODEL_NAME
    click.echo(f"  Model dir: {model_dir} ({'exists' if model_dir.exists() else 'missing'})")

    # Python deps
    try:
        ensure_transformer_deps(auto_install=False)
        click.echo("- Python deps: sentence-transformers stack: ok")
    except Exception as e:
        click.echo(f"- Python deps: missing ({e})")
    click.echo(f"  Auto-install deps: {'enabled' if Config.AUTO_INSTALL_DEPS else 'disabled'}")

    # DB info
    client = DatabaseClient()
    try:
        client.connect()
        click.echo("- Postgres:")
        click.echo(
            f"  Target: {Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB}"
        )
        try:
            vr = client.fetch_one("SHOW server_version")
            if vr and vr.get("server_version"):
                click.echo(f"  Version: v{vr['server_version']}")
        except Exception:
            pass

        # pgvector status
        try:
            ext = client.fetch_one(
                "SELECT extversion FROM pg_extension WHERE extname = 'vector'"
            )
            if ext and ext.get("extversion"):
                click.echo(f"  pgvector: installed (v{ext['extversion']})")
            else:
                click.echo("  pgvector: not installed")
        except Exception as e:
            click.echo(f"  pgvector: error checking extension ({e})")

        # Schema checks
        click.echo("- Schema:")
        try:
            repos_ok = client.table_exists("repos")
            files_ok = client.table_exists("files")
            chunks_ok = client.table_exists("chunks")
            click.echo(f"  tables: repos={'yes' if repos_ok else 'no'}, files={'yes' if files_ok else 'no'}, chunks={'yes' if chunks_ok else 'no'}")

            # Embedding column and index (best-effort)
            col = client.fetch_one(
                """
                SELECT data_type FROM information_schema.columns
                WHERE table_schema='public' AND table_name='chunks' AND column_name='embedding'
                """
            )
            click.echo(
                f"  embedding column: {'yes' if (col and col.get('data_type')) else 'no'}"
            )
            idx = client.fetch_one(
                """
                SELECT EXISTS (
                    SELECT 1 FROM pg_indexes
                    WHERE schemaname='public' AND tablename='chunks' AND indexname='chunks_embedding_idx'
                ) AS exists
                """
            )
            idx_ok = bool(idx and idx.get("exists"))
            click.echo(f"  vector index: {'yes' if idx_ok else 'no'}")
        except Exception as e:
            click.echo(f"  Error checking schema: {e}")

        # Basic counts (optional)
        try:
            if client.table_exists("repos"):
                r = client.fetch_one("SELECT COUNT(*) AS n FROM repos")
                click.echo(f"- Counts: repos={r['n'] if r else 0}")
            if client.table_exists("files"):
                f = client.fetch_one("SELECT COUNT(*) AS n FROM files")
                click.echo(f"          files={f['n'] if f else 0}")
            if client.table_exists("chunks"):
                c = client.fetch_one("SELECT COUNT(*) AS n FROM chunks")
                click.echo(f"          chunks={c['n'] if c else 0}")
        except Exception:
            pass
    except Exception as e:
        click.echo("- Postgres:")
        click.echo(
            f"  Target: {Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB}"
        )
        click.echo(f"  Status: unavailable ({e})")
    finally:
        try:
            client.close()
        except Exception:
            pass


@main.group(name="model")
def model_group() -> None:
    """Model management commands (download, info)."""
    pass


@model_group.command(name="download")
@click.option(
    "--dest",
    type=click.Path(file_okay=False, dir_okay=True, writable=True, path_type=Path),
    help="Destination directory for the model (defaults to ~/.savant/models/<name>/<version>)",
)
@click.option("--repo", default=None, help="HF repo id (default from config)")
@click.option("--revision", default=None, help="HF revision (commit/tag) to pin")
def model_download(dest: Path | None, repo: str | None, revision: str | None) -> None:
    """Download the pinned embedding model on demand."""
    try:
        target = download_model(dest=dest, repo_id=repo, revision=revision)
        click.echo(f"✓ Model downloaded to: {target}")
        click.echo("To use it, set:")
        click.echo(f"  export EMBEDDING_MODEL_DIR='{target}'")
    except Exception as e:
        click.echo(f"Error: Failed to download model: {e}", err=True)
        raise click.Abort()


@model_group.command(name="info")
def model_info() -> None:
    """Show current model configuration and expected paths."""
    click.echo("Model configuration:")
    click.echo(f"  Name:     {Config.EMBEDDING_MODEL_NAME}")
    click.echo(f"  Version:  {Config.EMBEDDING_VERSION}")
    click.echo(f"  Repo:     {Config.EMBEDDING_REPO_ID}")
    click.echo(f"  Revision: {Config.EMBEDDING_REVISION}")
    click.echo(f"  Default local dir: {default_model_dir()}")
    if Config.EMBEDDING_MODEL_DIR:
        p = Path(Config.EMBEDDING_MODEL_DIR)
        click.echo(f"  EMBEDDING_MODEL_DIR set: {p} {'(exists)' if p.exists() else '(missing)'}")


@main.group()
def db() -> None:
    """Database management commands."""
    pass


@db.command(name="setup")
def db_setup() -> None:
    """Initialize the database and create schema."""
    click.echo("Setting up database...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Connect and initialize schema
        db_client = get_db_client()
        init_schema(db_client)
        click.echo("✓ Database schema initialized successfully")
        db_client.close()

    except Exception as e:
        click.echo(f"Error: Failed to initialize database: {e}", err=True)
        raise click.Abort()


@db.command(name="dump")
@click.argument("output_path", type=click.Path())
def db_dump(output_path: str) -> None:
    """Dump the database to a file.

    OUTPUT_PATH: Path where to save the dump file
    """
    output_file = Path(output_path)

    if output_file.exists():
        if not click.confirm(f"File {output_path} exists. Overwrite?"):
            click.echo("Aborted")
            return

    click.echo(f"Dumping database to {output_path}...")

    try:
        dump_database(output_file)
        click.echo(f"✓ Database dumped successfully to {output_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="restore")
@click.argument("dump_path", type=click.Path(exists=True))
@click.option("--clean", is_flag=True, help="Drop objects before restoring")
def db_restore(dump_path: str, clean: bool) -> None:
    """Restore the database from a dump file.

    DUMP_PATH: Path to the dump file
    """
    if not click.confirm(f"Restore database from {dump_path}? This will replace existing data."):
        click.echo("Aborted")
        return

    click.echo(f"Restoring database from {dump_path}...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Restore from dump
        restore_database(Path(dump_path), clean=clean)
        click.echo(f"✓ Database restored successfully from {dump_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="destroy")
def db_destroy() -> None:
    """Destroy the database completely.

    WARNING: This permanently deletes all indexed data.
    """
    if not click.confirm("⚠️  This will permanently delete ALL indexed data. Are you sure?"):
        click.echo("Aborted")
        return

    if not click.confirm("Type 'destroy' to confirm permanent deletion"):
        click.echo("Aborted")
        return

    click.echo("Destroying database...")

    try:
        db_client = get_db_client()

        # Drop all tables
        db_client.execute("DROP TABLE IF EXISTS chunks CASCADE")
        db_client.execute("DROP TABLE IF EXISTS files CASCADE")
        db_client.execute("DROP TABLE IF EXISTS repos CASCADE")

        click.echo("✓ Database destroyed successfully")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="psql")
def db_psql() -> None:
    """Open psql shell to the database."""
    import subprocess

    try:
        # Build psql command
        cmd = [
            "psql",
            "-h", Config.POSTGRES_HOST,
            "-p", str(Config.POSTGRES_PORT),
            "-U", Config.POSTGRES_USER,
            "-d", Config.POSTGRES_DB,
        ]

        click.echo(f"Connecting to PostgreSQL at {Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB}...")

        # Execute psql
        subprocess.run(cmd, check=False)

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show detailed status of indexed repositories."""
    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Get repository stats with language breakdown
        repos = db_client.fetch_all(
            """
            SELECT
                r.id,
                r.name,
                r.indexed_at,
                COUNT(DISTINCT f.id) as file_count,
                COUNT(DISTINCT c.id) as chunk_count
            FROM repos r
            LEFT JOIN files f ON r.id = f.repo_id
            LEFT JOIN chunks c ON f.id = c.file_id
            GROUP BY r.id, r.name, r.indexed_at
            ORDER BY r.name
            """
        )

        if not repos:
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Display repository header
        click.echo("\n" + "=" * 100)
        click.echo("📊 REPOSITORY STATUS")
        click.echo("=" * 100)


        for repo in repos:
            repo_id = repo["id"]
            repo_name = repo["name"]
            file_count = repo["file_count"] or 0
            chunk_count = repo["chunk_count"] or 0
            indexed_at = repo["indexed_at"] or "Never"

            # Get language breakdown for this repo
            lang_stats = db_client.fetch_all(
                """
                SELECT language, COUNT(*) as count
                FROM files
                WHERE repo_id = %s
                GROUP BY language
                ORDER BY count DESC
                """,
                (repo_id,)
            )

            click.echo(f"\n📁 {repo_name}")
            click.echo("─" * 100)
            click.echo(f"  Last Indexed: {indexed_at}")
            click.echo(f"  Files (Memory Bank): {file_count:,}")
            click.echo(f"  Chunks (FTS Index): {chunk_count:,}")

            # Show file breakdown by type
            if lang_stats:
                click.echo(f"  Files by Type:")
                for lang_stat in lang_stats:
                    lang = lang_stat["language"] or "unknown"
                    count = lang_stat["count"]
                    percentage = (count / file_count * 100) if file_count > 0 else 0
                    click.echo(f"    • {lang:<15} {count:>6,} files ({percentage:>5.1f}%)")

        click.echo("\n" + "=" * 100 + "\n")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.group()
def index() -> None:
    """Repository indexing commands."""
    pass


@index.command(name="repo")
@click.argument("path", type=click.Path(exists=True, file_okay=False, dir_okay=True), required=False, default=".")
@click.option("--name", default=None, help="Repository name (default: folder name)")
def index_repo(path: str, name: Optional[str]) -> None:
    """Index a repository.

    PATH: Path to the repository to index (default: current directory)
    """
    repo_path = Path(path).resolve()
    repo_name = name or repo_path.name

    click.echo(f"Indexing repository: {repo_name}")
    click.echo(f"Path: {repo_path}")

    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            raise click.Abort()

        # Ensure pgvector is usable before attempting to index
        try:
            verify_vector_support(db_client)
        except Exception as e:
            click.echo(
                "pgvector is not available or misconfigured.\n"
                f"Details: {e}\n"
                "Run: savant-context db setup\n"
                "If this persists, (Homebrew) reinstall pgvector or savant-context."
            )
            raise click.Abort()

        indexer = Indexer(db_client)
        result = indexer.index_repository(repo_path, repo_name=repo_name, verbose=True)

        click.echo("\n✓ Indexing complete")
        click.echo(f"  Files indexed: {result['files_indexed']}")
        click.echo(f"  Chunks indexed: {result['chunks_indexed']}")
        if result["errors"]:
            click.echo(f"  Errors: {result['errors']}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.command()
def readme() -> None:
    """Display the full README documentation."""
    # Try multiple paths to find README
    possible_paths = [
        Path(__file__).parent.parent / "README.md",  # Development mode
        Path(__file__).parent.parent.parent / "README.md",  # Installed in site-packages
        Path("/opt/homebrew/Cellar/savant-context").glob("*/README.md"),  # Homebrew install
    ]

    readme_path = None
    for path in possible_paths:
        if isinstance(path, Path) and path.exists():
            readme_path = path
            break
        elif hasattr(path, '__iter__'):
            try:
                readme_path = next(path)
                break
            except StopIteration:
                continue

    if not readme_path or (isinstance(readme_path, Path) and not readme_path.exists()):
        # Fallback: Show a basic help message
        click.echo("Savant Context - MCP Server with Code Indexer")
        click.echo("")
        click.echo("For more information, visit: https://github.com/ashabbir/context")
        click.echo("")
        click.echo("Available commands:")
        click.echo("  savant-context run              Start MCP server")
        click.echo("  savant-context db setup         Initialize database")
        click.echo("  savant-context index repo       Index a repository")
        click.echo("  savant-context status           Show repository status")
        click.echo("  savant-context tool code_search  Search indexed code")
        return

    try:
        with open(readme_path, "r", encoding="utf-8") as f:
            content = f.read()
        click.echo(content)
    except Exception as e:
        click.echo(f"Error reading README: {e}", err=True)
        raise click.Abort()


@main.group(name="memory")
def memory() -> None:
    """Memory bank management commands."""
    pass


@memory.command(name="search")
@click.argument("query")
@click.option("--repo", default=None, help="Filter by repository")
@click.option("--limit", default=20, type=int, help="Maximum results (1-100)")
@click.option(
    "--format",
    type=click.Choice(["table", "json", "text"]),
    default="table",
    help="Output format",
)
def memory_search(query: str, repo: Optional[str], limit: int, format: str) -> None:
    """Search memory bank documents.

    QUERY: Search query (e.g., 'architecture patterns')

    Examples:
        savant-context memory search "architecture"
        savant-context memory search "API design" --repo my-project
        savant-context memory search "patterns" --format json
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_bank_search(query=query, repo=repo, limit=limit)

        if format == "json":
            click.echo(json.dumps(result, indent=2, default=str))
        else:
            _display_memory_search(result, format)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@memory.command(name="list")
@click.option("--repo", default=None, help="Filter by repository")
@click.option(
    "--sort",
    type=click.Choice(["name", "size", "created", "updated"]),
    default="name",
    help="Sort by field",
)
@click.option(
    "--format",
    type=click.Choice(["table", "json", "tree"]),
    default="table",
    help="Output format",
)
@click.option("--show-chunks", is_flag=True, help="Include chunk count")
def memory_list(
    repo: Optional[str], sort: str, format: str, show_chunks: bool
) -> None:
    """List all memory bank resources.

    Examples:
        savant-context memory list
        savant-context memory list --repo my-project --format tree
        savant-context memory list --show-chunks
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_list(repo=repo)

        if format == "json":
            click.echo(json.dumps(result, indent=2, default=str))
        else:
            _display_memory_list(result, sort, show_chunks, format)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@memory.command(name="read")
@click.argument("uri")
@click.option("--raw", is_flag=True, help="Output raw markdown without formatting")
@click.option("--less", is_flag=True, help="Pipe to less pager")
@click.option(
    "--format",
    type=click.Choice(["markdown", "text", "html"]),
    default="markdown",
    help="Output format",
)
def memory_read(uri: str, raw: bool, less: bool, format: str) -> None:
    """Read a memory bank document by URI.

    URI: Resource URI in format 'repo:path' or just 'path'

    Examples:
        savant-context memory read "memory_bank/architecture.md"
        savant-context memory read "my-project:memory_bank/api.md"
        savant-context memory read memory_bank/design.md --less
    """
    from .mcp.tools import ToolHandler
    import subprocess

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_read(uri=uri)

        if "error" in result:
            click.echo(f"Error: {result['error']}", err=True)
            raise click.Abort()

        content = result.get("content", "")

        # Format content
        if format == "html":
            output = f"<h1>{result.get('path')}</h1>\n<pre>{content}</pre>"
        else:
            output = content if raw else f"# {result.get('path')}\n\n{content}"

        # Pipe to less if requested
        if less:
            try:
                process = subprocess.Popen(["less"], stdin=subprocess.PIPE, text=True)
                process.communicate(input=output)
            except FileNotFoundError:
                click.echo(output)
        else:
            click.echo(output)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@memory.command(name="stats")
@click.option("--repo", default=None, help="Filter by repository")
@click.option(
    "--format", type=click.Choice(["table", "json"]), default="table", help="Output format"
)
@click.option("--detail", is_flag=True, help="Show detailed breakdown")
def memory_stats(repo: Optional[str], format: str, detail: bool) -> None:
    """Show memory bank statistics.

    Examples:
        savant-context memory stats
        savant-context memory stats --repo my-project --detail
        savant-context memory stats --format json
    """
    db_client = get_db_client()

    try:
        # Query memory bank stats
        if repo:
            stats = db_client.fetch_all(
                """
                SELECT r.name, COUNT(f.id) as file_count, COUNT(c.id) as chunk_count
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                LEFT JOIN chunks c ON f.id = c.file_id
                WHERE f.is_memory_bank = TRUE AND r.name = %s
                GROUP BY r.name
                """,
                (repo,),
            )
        else:
            stats = db_client.fetch_all(
                """
                SELECT r.name, COUNT(f.id) as file_count, COUNT(c.id) as chunk_count
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                LEFT JOIN chunks c ON f.id = c.file_id
                WHERE f.is_memory_bank = TRUE
                GROUP BY r.name
                ORDER BY r.name
                """
            )

        if format == "json":
            click.echo(json.dumps([dict(s) for s in stats], indent=2, default=str))
        else:
            _display_memory_stats(stats, detail)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@memory.command(name="export")
@click.argument("path", type=click.Path())
@click.option("--repo", default=None, help="Export specific repository")
@click.option(
    "--format",
    type=click.Choice(["dir", "zip", "tar.gz"]),
    default="dir",
    help="Export format",
)
@click.option("--include-metadata", is_flag=True, help="Include metadata file")
def memory_export(path: str, repo: Optional[str], format: str, include_metadata: bool) -> None:
    """Export memory bank to file or directory.

    PATH: Export destination

    Examples:
        savant-context memory export ./backup
        savant-context memory export ./backup.zip --format zip
    """
    import shutil
    from datetime import datetime

    db_client = get_db_client()

    try:
        export_path = Path(path)

        # Create temp directory for export
        temp_dir = Path("/tmp") / f"memory_bank_export_{datetime.now().timestamp()}"
        temp_dir.mkdir(exist_ok=True)

        # Query memory bank files
        if repo:
            files = db_client.fetch_all(
                """
                SELECT f.rel_path, f.id, r.name
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                WHERE f.is_memory_bank = TRUE AND r.name = %s
                ORDER BY f.rel_path
                """,
                (repo,),
            )
        else:
            files = db_client.fetch_all(
                """
                SELECT f.rel_path, f.id, r.name
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                WHERE f.is_memory_bank = TRUE
                ORDER BY r.name, f.rel_path
                """
            )

        if not files:
            click.echo("No memory bank files found to export.")
            return

        click.echo(f"Exporting {len(files)} memory bank files...")

        # Export each file
        exported_count = 0
        for file_record in files:
            rel_path = file_record["rel_path"]
            file_id = file_record["id"]

            # Get chunks
            chunks = db_client.fetch_all(
                """
                SELECT content FROM chunks WHERE file_id = %s ORDER BY chunk_index
                """,
                (file_id,),
            )

            if chunks:
                content = "\n".join([c["content"] for c in chunks])

                # Create file in temp directory
                file_path = temp_dir / rel_path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)

                click.echo(f"  ✓ {rel_path}")
                exported_count += 1

        # Include metadata if requested
        if include_metadata:
            metadata = {
                "export_date": datetime.now().isoformat(),
                "file_count": exported_count,
                "repository": repo or "all",
            }
            with open(temp_dir / ".metadata.json", "w", encoding="utf-8") as f:
                json.dump(metadata, f, indent=2)

        # Create final export
        if format == "dir":
            if export_path.exists():
                if not click.confirm(f"{path} exists. Overwrite?"):
                    click.echo("Aborted")
                    return
                shutil.rmtree(export_path)
            shutil.copytree(temp_dir, export_path)
            click.echo(f"\n✓ Export complete to {path}")
        elif format == "zip":
            shutil.make_archive(str(export_path.with_suffix("")), "zip", temp_dir)
            click.echo(f"\n✓ Export complete to {path}.zip")
        elif format == "tar.gz":
            shutil.make_archive(str(export_path.with_suffix("")), "gztar", temp_dir)
            click.echo(f"\n✓ Export complete to {path}.tar.gz")

        # Cleanup
        shutil.rmtree(temp_dir)

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@memory.command(name="validate")
@click.option("--repo", default=None, help="Validate specific repository")
@click.option("--fix", is_flag=True, help="Attempt to fix issues")
@click.option(
    "--format", type=click.Choice(["text", "json"]), default="text", help="Output format"
)
def memory_validate(repo: Optional[str], fix: bool, format: str) -> None:
    """Validate memory bank integrity.

    Examples:
        savant-context memory validate
        savant-context memory validate --repo my-project --fix
        savant-context memory validate --format json
    """
    db_client = get_db_client()

    try:
        # Check for orphaned chunks
        orphaned = db_client.fetch_all(
            """
            SELECT COUNT(*) as count FROM chunks
            WHERE file_id NOT IN (SELECT id FROM files)
            """
        )

        orphaned_count = orphaned[0]["count"] if orphaned else 0

        # Check for files without chunks
        no_chunks = db_client.fetch_all(
            """
            SELECT f.id, f.rel_path FROM files f
            WHERE f.is_memory_bank = TRUE
            AND f.id NOT IN (SELECT DISTINCT file_id FROM chunks)
            ORDER BY f.rel_path
            """
        )

        # Build report
        issues = []
        if orphaned_count > 0:
            issues.append(f"Found {orphaned_count} orphaned chunks")
        if no_chunks:
            issues.append(f"Found {len(no_chunks)} files without chunks")

        if format == "json":
            report = {
                "status": "healthy" if not issues else "issues_found",
                "orphaned_chunks": orphaned_count,
                "files_without_chunks": len(no_chunks) if no_chunks else 0,
                "issues": issues,
            }
            click.echo(json.dumps(report, indent=2))
        else:
            click.echo()
            click.echo("=" * 70)
            click.echo("MEMORY BANK VALIDATION")
            click.echo("=" * 70)

            if issues:
                click.echo(f"\nStatus: ⚠️  ISSUES FOUND")
                for issue in issues:
                    click.echo(f"  • {issue}")

                if fix:
                    if orphaned_count > 0:
                        db_client.execute("DELETE FROM chunks WHERE file_id NOT IN (SELECT id FROM files)")
                        click.echo(f"\n✓ Deleted {orphaned_count} orphaned chunks")
                    if no_chunks:
                        for file_rec in no_chunks:
                            click.echo(f"⚠️  File without chunks: {file_rec['rel_path']}")
            else:
                click.echo("\nStatus: ✓ HEALTHY")

            click.echo()

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


# Helper functions for display
def _display_memory_search(result: dict, format: str) -> None:
    """Display memory search results."""
    click.echo()
    click.echo("=" * 100)
    click.echo("MEMORY BANK SEARCH RESULTS")
    click.echo("=" * 100)

    if not result.get("results"):
        click.echo("No results found.")
        return

    if format == "table":
        click.echo(f"{'Repo':<15} {'File':<35} {'Rank':<8} Preview")
        click.echo("-" * 100)

        for r in result["results"]:
            repo = r.get("repo", "?")[:15]
            path = r.get("file_path", "?")[-35:]
            rank = f"{r.get('rank', 0):.2f}"
            content_preview = r.get("content", "")[:40].replace("\n", " ")

            click.echo(f"{repo:<15} {path:<35} {rank:<8} {content_preview}...")
    else:  # text format
        for r in result["results"]:
            click.echo(f"\nFile: {r.get('file_path')}")
            click.echo(f"Repo: {r.get('repo')}")
            click.echo(f"Rank: {r.get('rank')}")
            click.echo(f"Content: {r.get('content')[:100]}...")


def _display_memory_list(result: dict, sort: str, show_chunks: bool, format: str) -> None:
    """Display memory bank file list."""
    click.echo()
    click.echo("=" * 100)
    click.echo("MEMORY BANK RESOURCES")
    click.echo("=" * 100)

    resources = result.get("resources", [])
    if not resources:
        click.echo("No memory bank files found.")
        return

    # Sort resources
    sort_key = {
        "name": lambda r: r.get("path", ""),
        "size": lambda r: r.get("chunk_count", 0),
        "created": lambda r: r.get("created_at", ""),
        "updated": lambda r: r.get("indexed_at", ""),
    }.get(sort, lambda r: r.get("path", ""))

    sorted_resources = sorted(resources, key=sort_key)

    if format == "tree":
        # Group by repo
        repos = {}
        for resource in sorted_resources:
            repo = resource.get("repo", "unknown")
            if repo not in repos:
                repos[repo] = []
            repos[repo].append(resource)

        for repo_name in sorted(repos.keys()):
            click.echo(f"\n{repo_name}/")
            repo_resources = repos[repo_name]
            for i, resource in enumerate(sorted(repo_resources, key=lambda r: r.get("path", ""))):
                is_last = i == len(repo_resources) - 1
                prefix = "└── " if is_last else "├── "
                path = resource.get("path", "?")
                if show_chunks:
                    chunks = resource.get("chunk_count", 0)
                    click.echo(f"  {prefix}{path} ({chunks} chunks)")
                else:
                    click.echo(f"  {prefix}{path}")
    else:  # table format
        if show_chunks:
            header = f"{'Repo':<20} {'File Path':<50} {'Chunks':<8}"
            click.echo(header)
            click.echo("-" * 100)
            for r in sorted_resources:
                click.echo(
                    f"{r.get('repo', '?'):<20} {r.get('path', '?'):<50} {r.get('chunk_count', 0):<8}"
                )
        else:
            header = f"{'Repo':<20} {'File Path':<70}"
            click.echo(header)
            click.echo("-" * 100)
            for r in sorted_resources:
                click.echo(f"{r.get('repo', '?'):<20} {r.get('path', '?'):<70}")


def _display_memory_stats(stats: list, detail: bool) -> None:
    """Display memory bank statistics."""
    click.echo()
    click.echo("=" * 80)
    click.echo("MEMORY BANK STATISTICS")
    click.echo("=" * 80)

    total_files = sum(s.get("file_count", 0) for s in stats)
    total_chunks = sum(s.get("chunk_count", 0) for s in stats)

    click.echo(f"\nTotal Repositories:  {len(stats)}")
    click.echo(f"Total Files:         {total_files}")
    click.echo(f"Total Chunks:        {total_chunks}")

    if detail and stats:
        click.echo("\nBY REPOSITORY:")
        click.echo("-" * 80)
        click.echo(f"{'Repo':<25} {'Files':<10} {'Chunks':<10}")
        click.echo("-" * 80)
        for stat in stats:
            click.echo(
                f"{stat.get('name', '?'):<25} {stat.get('file_count', 0):<10} {stat.get('chunk_count', 0):<10}"
            )

    click.echo()


@main.group()
def tool() -> None:
    """Call MCP tools directly from CLI."""
    pass


@tool.command(name="code_search")
@click.argument("query")
@click.option("--repo", default=None, help="Optional repository name")
@click.option("--limit", default=10, help="Maximum results (1-100)")
def tool_code_search(query: str, repo: Optional[str], limit: int) -> None:
    """Semantic code search across indexed repos.

    QUERY: Search query (e.g., 'def function_name')
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.code_search(query=query, repo=repo, limit=limit)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_bank_search")
@click.argument("query")
@click.option("--repo", default=None, help="Optional repository name")
@click.option("--limit", default=20, help="Maximum results (1-100)")
def tool_memory_bank_search(query: str, repo: Optional[str], limit: int) -> None:
    """Semantic search within memory bank markdown.

    QUERY: Search query
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_bank_search(query=query, repo=repo, limit=limit)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_resources_list")
@click.option("--repo", default=None, help="Optional repository name")
def tool_memory_resources_list(repo: Optional[str]) -> None:
    """List memory bank resources from DB."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_list(repo=repo)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_resources_read")
@click.argument("uri")
def tool_memory_resources_read(uri: str) -> None:
    """Read a memory bank resource by URI.

    URI: Resource URI (file path)
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_read(uri=uri)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="repos_list")
@click.option("--filter", default=None, help="Optional repository name filter")
@click.option("--max-length", default=4096, help="Maximum excerpt length")
def tool_repos_list(filter: Optional[str], max_length: int) -> None:
    """List indexed repos with README excerpts."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.repos_list(filter=filter, max_length=max_length)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="repo_status")
def tool_repo_status() -> None:
    """List per-repo index status counts."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.repo_status()

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


def savant_shortcut() -> None:
    """Shortcut command that automatically runs the MCP server."""
    import sys
    # Insert 'run' as the first argument after 'savant'
    sys.argv.insert(1, 'run')
    main()


if __name__ == "__main__":
    main()
