"""Database schema creation and initialization for vector-only search."""

import logging

from .client import DatabaseClient

logger = logging.getLogger(__name__)

SCHEMA_SQL = """
-- Enable pgvector extension (required). Will fail if extension not installed.
CREATE EXTENSION IF NOT EXISTS vector;

-- Repositories table
CREATE TABLE IF NOT EXISTS repos (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    path TEXT NOT NULL,
    indexed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Files table
CREATE TABLE IF NOT EXISTS files (
    id SERIAL PRIMARY KEY,
    repo_id INTEGER NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    rel_path TEXT NOT NULL,
    language TEXT,
    is_memory_bank BOOLEAN DEFAULT FALSE,
    mtime_ns BIGINT,
    indexed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(repo_id, rel_path)
);

-- Chunks table with vector embedding (768 dims)
CREATE TABLE IF NOT EXISTS chunks (
    id SERIAL PRIMARY KEY,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    embedding vector(768) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Vector index for approximate nearest neighbors (cosine distance)
CREATE INDEX IF NOT EXISTS chunks_embedding_idx
ON chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Other useful indexes
CREATE INDEX IF NOT EXISTS files_repo_id_idx ON files(repo_id);
CREATE INDEX IF NOT EXISTS files_language_idx ON files(language);
CREATE INDEX IF NOT EXISTS files_memory_bank_idx ON files(is_memory_bank, repo_id);
CREATE INDEX IF NOT EXISTS chunks_file_id_idx ON chunks(file_id);
CREATE INDEX IF NOT EXISTS repos_name_idx ON repos(name);
"""


def init_schema(db_client: DatabaseClient) -> None:
    """Initialize database schema.

    Args:
        db_client: DatabaseClient instance

    Raises:
        Exception: If schema initialization fails
    """
    logger.info("Initializing database schema...")

    try:
        # Execute the entire schema at once
        try:
            db_client.execute(SCHEMA_SQL)
            logger.debug("Executed complete schema")
        except Exception as e:
            logger.warning(f"Schema execution warning: {e}")

        # Ensure vector schema is present; if not, perform a minimal migration for chunks
        try:
            verify_vector_support(db_client)
        except Exception:
            logger.warning("Vector schema incomplete; attempting to migrate 'chunks' table...")
            # Drop legacy search artifacts by replacing chunks table
            db_client.execute("DROP TABLE IF EXISTS chunks CASCADE;")
            db_client.execute(
                """
                CREATE TABLE IF NOT EXISTS chunks (
                    id SERIAL PRIMARY KEY,
                    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
                    chunk_index INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    embedding vector(768) NOT NULL,
                    created_at TIMESTAMP DEFAULT NOW()
                );
                """
            )
            db_client.execute(
                "CREATE INDEX IF NOT EXISTS chunks_embedding_idx ON chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)"
            )
            verify_vector_support(db_client)

        logger.info("Database schema initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database schema: {e}")
        raise


def drop_schema(db_client: DatabaseClient) -> None:
    """Drop all tables (for testing/cleanup).

    Args:
        db_client: DatabaseClient instance
    """
    logger.warning("Dropping all tables...")

    drop_sql = """
    DROP TABLE IF EXISTS chunks CASCADE;
    DROP TABLE IF EXISTS files CASCADE;
    DROP TABLE IF EXISTS repos CASCADE;
    """

    try:
        statements = [s.strip() for s in drop_sql.split(";") if s.strip()]
        for statement in statements:
            db_client.execute(statement)
        logger.info("All tables dropped")
    except Exception as e:
        logger.error(f"Failed to drop tables: {e}")
        raise


def verify_vector_support(db_client: DatabaseClient) -> None:
    """Fail fast if pgvector or embedding schema is not available.

    Checks:
    - pgvector extension installed
    - chunks table has embedding column of vector type
    - vector index exists (best-effort check)
    """
    # Check pgvector extension
    ext_row = db_client.fetch_one(
        "SELECT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'vector') AS exists"
    )
    if not ext_row or not ext_row.get("exists"):
        raise RuntimeError(
            "pgvector extension is not installed. Install it and run 'db setup'."
        )

    # Check embedding column on chunks
    col_row = db_client.fetch_one(
        """
        SELECT data_type
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'chunks' AND column_name = 'embedding'
        """
    )
    if not col_row:
        raise RuntimeError("Missing 'embedding' column on 'chunks' table. Run 'db setup'.")

    # Optional: validate vector index exists
    idx_row = db_client.fetch_one(
        """
        SELECT EXISTS (
            SELECT 1 FROM pg_indexes
            WHERE schemaname = 'public' AND tablename = 'chunks' AND indexname = 'chunks_embedding_idx'
        ) AS exists
        """
    )
    if not idx_row or not idx_row.get("exists"):
        logger.warning("Vector index 'chunks_embedding_idx' not found. Creating it now.")
        try:
            db_client.execute(
                "CREATE INDEX IF NOT EXISTS chunks_embedding_idx ON chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)"
            )
        except Exception as e:
            logger.warning(f"Could not create ivfflat index: {e}")
