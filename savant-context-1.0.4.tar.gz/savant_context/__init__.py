"""Savant Context MCP - Code indexer and context provider."""

__version__ = "1.0.4"
__author__ = "Ashabbir"
__email__ = "ashabbir@github.com"

__all__ = ["__version__"]
