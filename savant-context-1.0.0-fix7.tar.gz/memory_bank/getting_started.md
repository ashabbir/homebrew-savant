# Getting Started with the Memory Bank

This short guide helps you and your teammates start using the Memory Bank quickly.

## Quick Steps
- Initialize DB: `savant-context db setup`
- Index this repo: `savant-context index repo . --name context`
- Verify status: `savant-context status`
- List docs: `savant-context memory list --repo context`
- Search docs: `savant-context memory search "architecture" --repo context`
- Read this doc: `savant-context memory read "context:memory_bank/getting_started.md"`

## Suggested Structure
- `memory_bank/README.md` — high-level overview and entry points
- `memory_bank/architecture.md` — system diagrams and architecture notes
- `memory_bank/decisions/` — ADR-style decision records
- `memory_bank/onboarding/` — new-hire or contributor onboarding steps
- `memory_bank/runbooks/` — operational playbooks and procedures
- `memory_bank/glossary.md` — domain terms and definitions

## Tips
- Re-run `savant-context index repo . --name context` after adding or changing Markdown files.
- Use `--format json` on list/search commands for scripting.
- URIs accept `repo:path` (recommended) or just `path` if repo context is implied.
- Keep docs reasonably sized; large files are chunked but very large files may be skipped.
