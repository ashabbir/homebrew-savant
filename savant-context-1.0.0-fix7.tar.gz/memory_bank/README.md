# Memory Bank — Minimal Guide

Goal: Help developers quickly add and search Markdown knowledge inside a repo.

What is the Memory Bank?
- Markdown knowledge files kept alongside your code.
- Common locations: `memory_bank/` (this folder), `docs/`, `notes/`, or top-level `.md` files.
- During indexing, these are detected and flagged as Memory Bank content.

Quick Start
- Initialize DB: `savant-context db setup`
- Index this repo (example): `savant-context index repo . --name context`
- List docs: `savant-context memory list --repo context`
- Search: `savant-context memory search "architecture" --repo context`
- Read a doc: `savant-context memory read "context:memory_bank/README.md"`
- Stats: `savant-context memory stats --repo context`

Tips
- Use `--format json` to export results for scripts.
- URIs support `repo:path` or just `path` if the repo context is implied.
- After adding/editing Markdown, re-run `index repo` to refresh the index.

Next Steps
- See `memory_bank/getting_started.md` for a slightly deeper walkthrough and suggested folder structure.
