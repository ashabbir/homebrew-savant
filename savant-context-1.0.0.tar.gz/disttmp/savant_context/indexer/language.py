"""Memory bank and language detection for files."""

import re
from pathlib import Path
from typing import Tuple


class MemoryBankDetector:
    """Detects if a file is part of a memory bank collection."""

    # Directory names that indicate memory bank (normalized: dashes/underscores removed)
    MEMORY_DIR_NAMES = {"memory", "memorybank", "bank"}
    MARKDOWN_EXTS = {".md", ".mdx", ".markdown"}

    @staticmethod
    def normalize_path_segment(segment: str) -> str:
        """Normalize path segment by removing dashes and underscores.

        Args:
            segment: Path segment to normalize

        Returns:
            Normalized segment (lowercase, dashes/underscores removed)
        """
        return segment.lower().replace("-", "").replace("_", "")

    @classmethod
    def is_in_memory_dir(cls, rel_path: str) -> bool:
        """Check if file is in a memory bank directory.

        Args:
            rel_path: Relative file path

        Returns:
            True if file is in any memory bank directory
        """
        segments = rel_path.lower().split("/")
        normalized = [cls.normalize_path_segment(seg) for seg in segments]
        return any(seg in cls.MEMORY_DIR_NAMES for seg in normalized)

    @classmethod
    def is_markdown(cls, rel_path: str) -> bool:
        """Check if file has markdown extension.

        Args:
            rel_path: Relative file path

        Returns:
            True if file is markdown (.md, .mdx, .markdown)
        """
        ext = Path(rel_path).suffix.lower()
        return ext in cls.MARKDOWN_EXTS

    @classmethod
    def is_memory_bank_file(cls, rel_path: str) -> bool:
        """Determine if file is a memory bank document.

        Memory bank files must:
        1. Be in a memory bank directory (memory/memorybank/bank/etc.)
        2. Be a markdown file (.md, .mdx, .markdown)

        Args:
            rel_path: Relative file path

        Returns:
            True if file is a memory bank document
        """
        return cls.is_in_memory_dir(rel_path) and cls.is_markdown(rel_path)

    @classmethod
    def should_skip_in_memory_dir(cls, rel_path: str) -> bool:
        """Check if file should be skipped during indexing.

        Non-markdown files in memory directories should be skipped.

        Args:
            rel_path: Relative file path

        Returns:
            True if file is in memory dir but not markdown (should skip)
        """
        return cls.is_in_memory_dir(rel_path) and not cls.is_markdown(rel_path)

    @classmethod
    def detect_language(cls, rel_path: str) -> Tuple[str, bool]:
        """Detect language and whether file is memory bank.

        Args:
            rel_path: Relative file path

        Returns:
            Tuple of (language_tag, is_memory_bank)
            - language_tag: 'memory_bank' for memory bank files, file extension otherwise
            - is_memory_bank: True if file is a memory bank document
        """
        if cls.is_memory_bank_file(rel_path):
            return ("memory_bank", True)

        # For non-memory-bank files, return extension as language
        ext = Path(rel_path).suffix.lower()
        if ext:
            ext = ext.lstrip(".")
        language = ext if ext else "txt"

        return (language, False)
