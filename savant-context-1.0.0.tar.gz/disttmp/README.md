# Savant Context

MCP-compatible code search and indexing service backed by PostgreSQL. Index one or more repositories and run fast, accurate full‑text searches over your code and “memory bank” Markdown — from the CLI or any MCP client (e.g., Claude Desktop).

## Why Use It

- Fast FTS over code with PostgreSQL `tsvector`/`ts_rank`.
- Language-aware indexing with chunking for relevant results.
- Clean CLI and MCP tools with JSON outputs where appropriate.
- Zero-config: works via environment variables only.

## Install

### Homebrew

```bash
brew tap ashabbir/savant https://github.com/ashabbir/homebrew-savant
brew install savant-context
```

### From source

```bash
git clone https://github.com/ashabbir/context.git
cd context
pip install -e .
```

Requirements: Python 3.10+, PostgreSQL 12+ (tested on 15).

## Quick Start

```bash
# 1) Initialize database and schema
savant-context db setup

# 2) Index a repo
savant-context index repo ./path/to/repo --name my-project

# 3) Check status
savant-context status

# 4) Start MCP server (stdio)
savant-context run
```

Tip: `savant` is a shortcut for `savant-context run`.

## CLI Reference

All commands are available via `savant-context`.

### Database

- Init: `savant-context db setup`
- Dump: `savant-context db dump <output_path>`
- Restore: `savant-context db restore <dump_path> [--clean]`
- Destroy: `savant-context db destroy` (prompts twice)
- psql: `savant-context db psql`

### Indexing

- Index repo: `savant-context index repo [path] [--name <repo-name>]` (default path: `.`)
- Status: `savant-context status`

### Server

- Run MCP server: `savant-context run` (stdout is JSON-RPC only; banner/logs to stderr)

### Memory Bank

Commands for managing and searching memory bank documents (knowledge base Markdown files in `memory_bank/` or similar directories).

#### memory search
- Purpose: Full-text search of memory bank documents only.
- Syntax: `savant-context memory search <query> [OPTIONS]`
- Options:
  - `--repo <name>` Filter by repository
  - `--limit <N>` Maximum results (1-100, default 20)
  - `--format (table|json|text)` Output format (default: table)
- Examples:
```bash
savant-context memory search "architecture"
savant-context memory search "API design" --repo my-project --limit 5
savant-context memory search "patterns" --format json
```

#### memory list
- Purpose: List all indexed memory bank files with metadata.
- Syntax: `savant-context memory list [OPTIONS]`
- Options:
  - `--repo <name>` Filter by repository
  - `--sort (name|size|created|updated)` Sort field (default: name)
  - `--format (table|json|tree)` Output format (default: table)
  - `--show-chunks` Include chunk count for each file
- Examples:
```bash
savant-context memory list
savant-context memory list --repo my-project --format tree
savant-context memory list --sort updated --show-chunks
```

#### memory read
- Purpose: Display full content of a memory bank document.
- Syntax: `savant-context memory read <uri> [OPTIONS]`
- Options:
  - `--raw` Output raw markdown without formatting
  - `--less` Pipe to less pager
  - `--format (markdown|text|html)` Output format (default: markdown)
- Examples:
```bash
savant-context memory read "memory_bank/architecture.md"
savant-context memory read "my-project:memory_bank/api.md" --less
```

#### memory stats
- Purpose: Show memory bank usage statistics and breakdown by repository.
- Syntax: `savant-context memory stats [OPTIONS]`
- Options:
  - `--repo <name>` Filter by repository
  - `--format (table|json)` Output format (default: table)
  - `--detail` Show detailed breakdown
- Examples:
```bash
savant-context memory stats
savant-context memory stats --repo my-project --detail
savant-context memory stats --format json
```

#### memory export
- Purpose: Backup memory bank files to directory or archive.
- Syntax: `savant-context memory export <path> [OPTIONS]`
- Options:
  - `--repo <name>` Export specific repository only
  - `--format (dir|zip|tar.gz)` Export format (default: dir)
  - `--include-metadata` Include .metadata.json with export info
- Examples:
```bash
savant-context memory export ./backup
savant-context memory export ./backup.zip --format zip
savant-context memory export ./backup.tar.gz --format tar.gz
```

#### memory validate
- Purpose: Check memory bank integrity and consistency.
- Syntax: `savant-context memory validate [OPTIONS]`
- Options:
  - `--repo <name>` Validate specific repository
  - `--fix` Attempt to fix found issues
  - `--format (text|json)` Output format (default: text)
- Examples:
```bash
savant-context memory validate
savant-context memory validate --repo my-project --fix
savant-context memory validate --format json
```

### Utilities

- Show README: `savant-context readme`

## MCP Tools Reference

Each tool can be called via MCP or from the CLI for quick testing: `savant-context tool <name> [options]`.

### fts_search
- Purpose: Full‑text search across indexed repos.
- Options:
  - `--repo <name>` or multiple `--repo` values
  - `--limit <1-100>` (default 10)
  - Accepts `q` or `query` as the search string
- Example:
```bash
savant-context tool fts_search "def my_func" --repo my-project --limit 5
```

### memory_search
- Purpose: Search only memory bank Markdown.
- Options:
  - `--repo <name>` or multiple `--repo` values
  - `--limit <1-100>` (default 20)
  - Accepts `q` or `query` as the search string
- Example:
```bash
savant-context tool memory_search "setup steps" --repo my-project
```

### memory_resources_list
- Purpose: List memory bank resources (Markdown) with basic stats.
- Options:
  - `--repo <name>` or multiple `--repo` values
- Example:
```bash
savant-context tool memory_resources_list --repo my-project
```

### memory_resources_read
- Purpose: Read a memory bank resource by URI.
- Options:
  - `uri` (required), format `repo:path` or just `path`
- Example:
```bash
savant-context tool memory_resources_read "my-project:docs/overview.md"
```

### repos_list
- Purpose: List indexed repos with README excerpts and counts.
- Options:
  - `--filter <substring>`
  - `--max-length <256-16384>` (default 4096)
- Example:
```bash
savant-context tool repos_list --filter context
```

### fs_repo_status
- Purpose: Per‑repo index status (file/chunk counts).
- Options: none
- Example:
```bash
savant-context tool fs_repo_status
```

## Configuration

Environment variables only (no config files):

```bash
# PostgreSQL
export POSTGRES_HOST=localhost                # default: localhost
export POSTGRES_PORT=5432                     # default: 5432
export POSTGRES_DB=savant-context-standalone  # default: savant-context-standalone
export POSTGRES_USER=$USER                    # default: current user
export POSTGRES_PASSWORD=                     # optional

# Logging
export LOG_LEVEL=info                         # default: info
```

## Claude Desktop & Claude Code (MCP)

Integrate Savant Context with Claude Desktop or Claude Code for MCP-based code search and indexing.

### Option A: CLI Configuration (Recommended)

For Claude Code, use the CLI command to add the MCP server:

```bash
claude mcp add --transport stdio savant --scope user -- savant-context run
```

Or for project-specific access only:

```bash
claude mcp add --transport stdio savant --scope local -- savant-context run
```

Verify the integration:

```bash
claude mcp list
# Output: savant: savant-context run - ✓ Connected
```

### Option B: Manual Configuration (Claude Desktop)

For Claude Desktop, add to your `claude_desktop_config.json` file:

**Location:**
- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- Linux: `~/.config/Claude/claude_desktop_config.json`

**Configuration:**

```json
{
  "mcpServers": {
    "savant-context": {
      "command": "savant-context",
      "args": ["run"]
    }
  }
}
```

After editing, restart Claude Desktop to activate the MCP server.

### Advanced Configuration (Optional)

For Claude Desktop, you can add advanced settings:

```json
{
  "mcpServers": {
    "savant-context": {
      "command": "savant-context",
      "args": ["run"],
      "type": "stdio",
      "timeout": 60,
      "env": {
        "LOG_LEVEL": "error"
      },
      "autoApprove": [
        "fts_search",
        "memory_search",
        "memory_resources_list",
        "memory_resources_read",
        "fs_repo_status",
        "repos_list"
      ],
      "disabled": false
    }
  }
}
```

**Configuration options:**
- `timeout`: Request timeout in seconds (default: 30, recommended: 60)
- `env`: Environment variables (e.g., `LOG_LEVEL`, `POSTGRES_HOST`)
- `autoApprove`: Tools to auto-approve without confirmation prompts
- `disabled`: Set to `true` to disable the server temporarily

### Verify Integration

In Claude Desktop or Claude Code, ask:
- "List the indexed repositories"
- "Search for `function_name` in the codebase"
- "What's the current indexing status?"

The MCP tools should respond with JSON results, confirming successful integration.

## VS Code (Claude Code Extension)

Integrate Savant Context directly with the Claude Code extension in VS Code.

### Installation & Setup

1. **Install savant-context**:
   ```bash
   brew tap ashabbir/savant https://github.com/ashabbir/homebrew-savant
   brew install savant-context
   ```

2. **Initialize database**:
   ```bash
   savant-context db setup
   ```

3. **Index repositories**:
   ```bash
   savant-context index repo /path/to/repo --name my-project
   ```

### Configure in Claude Code Extension

1. **Via CLI (Recommended)**:
   ```bash
   claude mcp add --transport stdio savant --scope user -- savant-context run
   ```

2. **Via Settings File**:
   - Create or edit `~/.claude.json`
   - Add the MCP server configuration:
   ```json
   {
     "mcpServers": {
       "savant": {
         "type": "stdio",
         "command": "savant-context",
         "args": ["run"]
       }
     }
   }
   ```

3. **Verify Integration**:
   ```bash
   claude mcp list
   # Should show: savant: savant-context run - ✓ Connected
   ```

### Using in Claude Code

- Open Claude Code in VS Code
- Use natural language to interact with your code:
  - "Search for `function_name` in the codebase"
  - "List all indexed repositories"
  - "What's the indexing status?"

Claude will automatically use the MCP tools to fulfill your requests.

## VS Code (Cline Extension)

Integrate Savant Context as an MCP server in Cline for code search and indexing.

### Installation & Setup

1. **Install savant-context** (if not already installed):
   ```bash
   brew tap ashabbir/savant https://github.com/ashabbir/homebrew-savant
   brew install savant-context
   ```
   Or from source:
   ```bash
   git clone https://github.com/ashabbir/context.git
   cd context
   pip install -e .
   ```

2. **Initialize database**:
   ```bash
   savant-context db setup
   ```

3. **Index repositories**:
   ```bash
   savant-context index repo /path/to/repo --name my-project
   savant-context index repo /path/to/another --name another-project
   ```

4. **Verify indexing**:
   ```bash
   savant-context status
   ```

### Configure Cline MCP Server

**Option A: VS Code Settings (Recommended)**

1. Open VS Code Settings (`Cmd+,` or `Ctrl+,`)
2. Search for "Cline" in settings
3. Find "MCP Servers" configuration section
4. Add a new MCP server entry:
   - **Name**: `savant-context`
   - **Command**: `savant-context`
   - **Arguments**: `run`
5. Save settings and reload VS Code

**Option B: Cline Configuration File**

If using Cline's config file (`.cline/settings.json` or similar), add:
```json
{
  "mcpServers": {
    "savant-context": {
      "command": "savant-context",
      "args": ["run"],
      "type": "stdio"
    }
  }
}
```

### Verify Integration

1. Open a new Cline chat in VS Code
2. Ask Cline: "List the indexed repositories"
3. Cline should use the `repos_list` MCP tool and return a JSON response with repository details

### Using the Tools in Cline

Once integrated, you can ask Cline to use the following tools:

- **fts_search**: Search across all indexed code
  - Example: "Search for 'def authenticate' in the codebase"
  - Returns: File locations, context, and match details

- **repos_list**: List all indexed repositories with metadata
  - Example: "Show me all indexed repositories and their status"

- **fs_repo_status**: Check indexing status per repository
  - Example: "What's the current indexing status?"

- **memory_search**: Search memory bank documents (if indexed)
  - Example: "Search for 'architecture' in memory bank"

- **memory_resources_list**: Browse memory bank resources
  - Example: "List all memory bank documents"

### Troubleshooting

| Issue | Solution |
|-------|----------|
| **Empty response or "tool not found"** | Verify MCP server started: Check VS Code Output panel → "Cline" tab for connection logs |
| **"Database not initialized"** | Run `savant-context db setup` in terminal |
| **No repositories found** | Run `savant-context index repo <path> --name <name>` to index at least one repo |
| **MCP connection timeout** | Ensure `savant-context` is in your PATH (test with `which savant-context`) |
| **Slow search responses** | Large repositories may take time for first search; results are cached in PostgreSQL |
| **"No such file or directory"** | Verify PostgreSQL is running: `brew services list \| grep postgres` |

### Advanced Configuration

**Environment Variables**

If you need custom PostgreSQL settings, set them before launching VS Code:

```bash
export POSTGRES_HOST=localhost
export POSTGRES_PORT=5432
export POSTGRES_DB=savant-context-standalone
export POSTGRES_USER=$(whoami)
code  # Launch VS Code with env vars
```

**Auto-Approve Tools** (Optional)

In Cline settings, enable "Auto-Approve Tools" or "Always Allow" for savant-context tools to skip confirmation dialogs.

## Notes

- Very large files may be skipped; indexing is incremental by mtime.
- FTS uses PostgreSQL GIN index on `chunks.content_vector`.
- The banner is shown for interactive CLI commands; hidden for `run`/`tool` to keep stdout clean.

## Contributing & License

MIT License. PRs welcome — please open an issue or pull request.
