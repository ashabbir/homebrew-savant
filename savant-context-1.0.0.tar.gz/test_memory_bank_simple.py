#!/usr/bin/env python3
"""Test script for memory bank detection - no DB dependencies."""

import sys
from pathlib import Path

# Add the context directory to path
sys.path.insert(0, str(Path(__file__).parent))

# Import just the language module (no DB deps)
from savant_context.indexer.language import MemoryBankDetector


def test_memory_bank_detection():
    """Test memory bank file detection."""

    test_cases = [
        # (rel_path, expected_is_memory_bank, description)
        ("memory_bank/architecture.md", True, "standard memory_bank"),
        ("memory/design.md", True, "memory variant"),
        ("memorybank/api.md", True, "memorybank variant"),
        ("memory-bank/notes.md", True, "memory-bank with dash"),
        ("MEMORY_BANK/guide.mdx", True, "uppercase with underscore"),
        ("bank/readme.md", True, "bank short form"),
        ("memory/notes.txt", False, "non-markdown in memory"),
        ("memory/config.json", False, "json in memory"),
        ("memory-bank/diagram.png", False, "image in memory"),
        ("docs/memory.md", False, "markdown outside memory dir"),
        ("README.md", False, "top-level markdown"),
        ("src/memory_bank_utils.py", False, "code file with memory in name"),
    ]

    print("=" * 70)
    print("MEMORY BANK DETECTION TESTS")
    print("=" * 70)

    passed = 0
    failed = 0

    for rel_path, expected, description in test_cases:
        result = MemoryBankDetector.is_memory_bank_file(rel_path)
        status = "✓ PASS" if result == expected else "✗ FAIL"

        if result == expected:
            passed += 1
        else:
            failed += 1

        print(f"\n{status}: {description}")
        print(f"  Path: {rel_path}")
        print(f"  Expected: {expected}, Got: {result}")

    print("\n" + "=" * 70)
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(test_cases)}")
    print("=" * 70)

    return failed == 0


def test_language_detection():
    """Test language and memory bank detection."""

    test_cases = [
        # (rel_path, expected_language, expected_is_memory_bank, description)
        ("memory_bank/architecture.md", "memory_bank", True, "memory bank markdown"),
        ("README.md", "md", False, "regular markdown"),
        ("src/main.py", "py", False, "python file"),
        ("memory/api.mdx", "memory_bank", True, "memory bank mdx"),
        ("memory/config.json", "json", False, "non-markdown in memory"),
    ]

    print("\n" + "=" * 70)
    print("LANGUAGE DETECTION TESTS")
    print("=" * 70)

    passed = 0
    failed = 0

    for rel_path, expected_lang, expected_mb, description in test_cases:
        lang, is_mb = MemoryBankDetector.detect_language(rel_path)
        status = "✓ PASS" if (lang == expected_lang and is_mb == expected_mb) else "✗ FAIL"

        if lang == expected_lang and is_mb == expected_mb:
            passed += 1
        else:
            failed += 1

        print(f"\n{status}: {description}")
        print(f"  Path: {rel_path}")
        print(f"  Expected: language={expected_lang}, is_mb={expected_mb}")
        print(f"  Got:      language={lang}, is_mb={is_mb}")

    print("\n" + "=" * 70)
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(test_cases)}")
    print("=" * 70)

    return failed == 0


def test_skip_logic():
    """Test skip logic for non-markdown files in memory dirs."""

    test_cases = [
        # (rel_path, expected_should_skip, description)
        ("memory/notes.txt", True, "text file in memory"),
        ("memory_bank/config.json", True, "json in memory bank"),
        ("memory-bank/diagram.png", True, "image in memory bank"),
        ("memory/architecture.md", False, "markdown in memory - should not skip"),
        ("docs/notes.txt", False, "text outside memory - should not skip"),
    ]

    print("\n" + "=" * 70)
    print("SKIP LOGIC TESTS")
    print("=" * 70)

    passed = 0
    failed = 0

    for rel_path, expected, description in test_cases:
        result = MemoryBankDetector.should_skip_in_memory_dir(rel_path)
        status = "✓ PASS" if result == expected else "✗ FAIL"

        if result == expected:
            passed += 1
        else:
            failed += 1

        print(f"\n{status}: {description}")
        print(f"  Path: {rel_path}")
        print(f"  Expected to skip: {expected}, Got: {result}")

    print("\n" + "=" * 70)
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(test_cases)}")
    print("=" * 70)

    return failed == 0


if __name__ == "__main__":
    results = [
        test_memory_bank_detection(),
        test_language_detection(),
        test_skip_logic(),
    ]

    if all(results):
        print("\n✅ ALL TESTS PASSED!")
        exit(0)
    else:
        print("\n❌ SOME TESTS FAILED")
        exit(1)
