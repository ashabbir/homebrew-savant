import json
import builtins
import datetime
import pytest

from savant_context.mcp.server import MCPServer

class DummyToolHandler:
    def code_search(self, q=None, query=None, repo=None, limit=10, exclude_memory_bank=False):
        return {
            "query": q or query,
            "repo_filter": repo,
            "result_count": 1,
            "results": [{"repo": "context", "file_path": "a.py", "content": "found"}],
        }

    def memory_bank_search(self, q=None, query=None, repo=None, limit=20):
        return {"query": q or query, "result_count": 0, "results": []}


def test_wrap_tool_result_serializes_datetime():
    server = MCPServer.__new__(MCPServer)
    # ensure method exists and serializes datetimes to ISO strings
    payload = {"time": datetime.datetime(2020, 1, 1, 0, 0, 0), "status": "ok"}
    wrapped = server._wrap_tool_result(payload)
    assert "content" in wrapped
    item = wrapped["content"][0]
    assert item["type"] == "text"
    parsed = json.loads(item["text"])
    assert parsed["status"] == "ok"
    assert parsed["time"] == "2020-01-01T00:00:00"


def test_run_parses_content_envelope_and_calls_code_search(monkeypatch, capsys):
    server = MCPServer.__new__(MCPServer)
    server.tool_handler = DummyToolHandler()

    request = {
        "jsonrpc": "2.0",
        "method": "code_search",
        "params": {
            "content": [{"type": "text", "text": "framework"}],
            "repo": "context",
            "limit": 5,
        },
        "id": 42,
    }

    inputs = [json.dumps(request)]

    def fake_input():
        if inputs:
            return inputs.pop(0)
        raise EOFError

    monkeypatch.setattr(builtins, "input", fake_input)

    # run should process one request and then exit on EOFError
    server.run()

    out = capsys.readouterr().out
    # The server prints a single JSON-RPC response; parse it
    resp = json.loads(out)
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 42
    result = resp["result"]
    assert "content" in result
    text = result["content"][0]["text"]
    payload = json.loads(text)
    assert payload["query"] == "framework"
    assert payload["result_count"] == 1


def test_run_accepts_q_param(monkeypatch, capsys):
    server = MCPServer.__new__(MCPServer)
    server.tool_handler = DummyToolHandler()

    request = {
        "jsonrpc": "2.0",
        "method": "code_search",
        "params": {"q": "framework", "repo": "context", "limit": 3},
        "id": 7,
    }
    inputs = [json.dumps(request)]

    def fake_input():
        if inputs:
            return inputs.pop(0)
        raise EOFError

    monkeypatch.setattr(builtins, "input", fake_input)

    server.run()

    out = capsys.readouterr().out
    resp = json.loads(out)
    result = resp["result"]
    text = result["content"][0]["text"]
    payload = json.loads(text)
    assert payload["query"] == "framework"
    assert payload["result_count"] == 1
