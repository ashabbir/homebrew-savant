"""PostgreSQL database client with connection pooling."""

import logging
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

import psycopg
from psycopg import sql

from ..config import Config

logger = logging.getLogger(__name__)


class DatabaseClient:
    """PostgreSQL client with simple connection management."""

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
    ):
        """Initialize database client.

        Args:
            host: PostgreSQL host (default: from config)
            port: PostgreSQL port (default: from config)
            database: Database name (default: from config)
            user: Database user (default: from config)
            password: Database password (default: from config)
        """
        self.host = host or Config.POSTGRES_HOST
        self.port = port or Config.POSTGRES_PORT
        self.database = database or Config.POSTGRES_DB
        self.user = user or Config.POSTGRES_USER
        self.password = password or Config.POSTGRES_PASSWORD
        self.connection: Optional[psycopg.Connection] = None

    def connect(self) -> None:
        """Create connection."""
        if self.connection is not None:
            return

        try:
            conninfo = (
                f"host={self.host} "
                f"port={self.port} "
                f"dbname={self.database} "
                f"user={self.user}"
            )
            if self.password:
                conninfo += f" password={self.password}"

            self.connection = psycopg.connect(conninfo)
            logger.info(f"Connected to PostgreSQL at {self.host}:{self.port}/{self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to PostgreSQL: {e}")
            raise

    def close(self) -> None:
        """Close connection."""
        if self.connection:
            self.connection.close()
            self.connection = None
            logger.info("Closed database connection")

    @contextmanager
    def get_cursor(self):
        """Get a cursor context manager."""
        if self.connection is None:
            raise RuntimeError("Database client not connected. Call connect() first.")
        cur = self.connection.cursor()
        try:
            yield cur
        finally:
            cur.close()

    def execute(self, query: str, params: Optional[tuple] = None) -> None:
        """Execute a query without returning results."""
        if self.connection is None:
            raise RuntimeError("Database client not connected. Call connect() first.")
        try:
            with self.get_cursor() as cur:
                cur.execute(query, params)
            self.connection.commit()
        except Exception as e:
            self.connection.rollback()
            logger.error(f"Query execution failed: {e}")
            raise

    def fetch_one(
        self, query: str, params: Optional[tuple] = None
    ) -> Optional[Dict[str, Any]]:
        """Execute a query and return one row as dict."""
        if self.connection is None:
            raise RuntimeError("Database client not connected. Call connect() first.")
        with self.get_cursor() as cur:
            cur.execute(query, params)
            row = cur.fetchone()
            if row:
                # Convert Row to dict
                return {col[0]: row[i] for i, col in enumerate(cur.description)}
            return None

    def fetch_all(
        self, query: str, params: Optional[tuple] = None
    ) -> List[Dict[str, Any]]:
        """Execute a query and return all rows as dicts."""
        if self.connection is None:
            raise RuntimeError("Database client not connected. Call connect() first.")
        with self.get_cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()
            if not rows:
                return []
            columns = [col[0] for col in cur.description]
            return [{col: row[i] for i, col in enumerate(columns)} for row in rows]

    def insert_many(
        self,
        table: str,
        columns: List[str],
        values: List[tuple],
        returning: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Insert multiple rows efficiently."""
        if not values:
            return []

        if self.connection is None:
            raise RuntimeError("Database client not connected. Call connect() first.")

        try:
            with self.get_cursor() as cur:
                placeholders = ", ".join(["%s"] * len(columns))
                insert_sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
                if returning:
                    insert_sql += f" RETURNING {returning}"

                cur.executemany(insert_sql, values)
                self.connection.commit()

                if returning:
                    rows = cur.fetchall()
                    if rows and cur.description:
                        columns = [col[0] for col in cur.description]
                        return [{col: row[i] for i, col in enumerate(columns)} for row in rows]
                return []
        except Exception as e:
            self.connection.rollback()
            logger.error(f"Batch insert failed: {e}")
            raise

    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists."""
        query = """
            SELECT EXISTS (
                SELECT 1 FROM information_schema.tables
                WHERE table_schema = 'public'
                AND table_name = %s
            )
        """
        result = self.fetch_one(query, (table_name,))
        return result and result.get("exists", False) if result else False
