"""Embedding utilities for vector search."""

from .model import EmbeddingModel

__all__ = ["EmbeddingModel"]

