"""Offline embedding model loader and encoder.

Uses a DistilBERT-based sentence transformer (768-dim) vendored in-repo.
"""

import os
import logging
from pathlib import Path
from typing import List, Sequence, Union


from ..config import Config
from ..utils.deps import ensure_transformer_deps

logger = logging.getLogger(__name__)


class EmbeddingModel:
    """Singleton-style embedding model loader with offline enforcement."""

    _instance = None

    def __init__(self, model_dir: Path):
        # Enforce offline mode to avoid any accidental downloads
        os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        os.environ.setdefault("HF_DATASETS_OFFLINE", "1")

        try:
            # Best-effort ensure dependencies are present for OOTB UX
            ensure_transformer_deps(auto_install=Config.AUTO_INSTALL_DEPS)
            from sentence_transformers import SentenceTransformer  # type: ignore
            import numpy as _np  # defer until deps ensured
        except Exception as e:
            raise RuntimeError(
                "Missing ML dependencies. Install with: \n"
                "  python -m pip install 'sentence-transformers>=2.2.2' 'torch>=2.0.0'\n"
                "Or set SAVANT_AUTO_INSTALL_DEPS=1 to allow auto-install."
            ) from e

        model_dir = Path(model_dir)
        if not model_dir.exists():
            raise RuntimeError(
                f"Embedding model directory not found: {model_dir}. "
                "Vendor the model files locally or set EMBEDDING_MODEL_DIR."
            )

        logger.info(f"Loading embedding model from {model_dir} (CPU)")
        # Always use CPU for determinism
        self._model = SentenceTransformer(str(model_dir), device="cpu")
        self._np = _np

    @classmethod
    def get(cls) -> "EmbeddingModel":
        if cls._instance is not None:
            return cls._instance

        # Resolve model directory
        if Config.EMBEDDING_MODEL_DIR:
            model_dir = Path(Config.EMBEDDING_MODEL_DIR)
        else:
            model_dir = Path(__file__).parent / "models" / Config.EMBEDDING_MODEL_NAME

        cls._instance = EmbeddingModel(model_dir)
        return cls._instance

    def embed(self, texts: Union[str, Sequence[str]]) -> "_np.ndarray":
        """Embed a single string or a sequence of strings.

        Returns a 2D numpy array of shape (n, 768).
        """
        if isinstance(texts, str):
            texts = [texts]

        # Use deterministic settings
        embeddings = self._model.encode(
            list(texts),
            batch_size=32,
            convert_to_numpy=True,
            normalize_embeddings=False,  # we rely on cosine distance operator in DB
            show_progress_bar=False,
        )
        return embeddings.astype(self._np.float32)

    def embed_one(self, text: str) -> List[float]:
        vec = self.embed(text)
        return vec[0].tolist()
