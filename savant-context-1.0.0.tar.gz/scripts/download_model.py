#!/usr/bin/env python3
"""Download the pinned embedding model on demand.

Usage:
  python -m scripts.download_model --dest /path/to/model
  or
  ./scripts/download_model.py --dest /path/to/model

If --dest is omitted, downloads to ~/.savant/models/<name>/<version>.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from savant_context.embeddings.downloader import download_model, default_model_dir


def main() -> None:
    parser = argparse.ArgumentParser(description="Download pinned embedding model")
    parser.add_argument(
        "--dest",
        type=Path,
        default=None,
        help="Destination directory for the model",
    )
    parser.add_argument(
        "--repo",
        type=str,
        default=None,
        help="Override Hugging Face repo id",
    )
    parser.add_argument(
        "--revision",
        type=str,
        default=None,
        help="Override Hugging Face revision to pin",
    )
    args = parser.parse_args()

    dest = args.dest or default_model_dir()
    dest = download_model(dest=dest, repo_id=args.repo, revision=args.revision)
    print(f"Model downloaded to: {dest}")
    print(f"Export to use: export EMBEDDING_MODEL_DIR='{dest}'")


if __name__ == "__main__":
    main()

