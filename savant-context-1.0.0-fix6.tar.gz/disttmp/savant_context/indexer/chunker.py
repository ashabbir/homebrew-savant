"""Content chunking for efficient indexing."""

import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)


class ContentChunker:
    """Split file content into searchable chunks."""

    # Default chunk size in lines
    DEFAULT_CHUNK_SIZE = 500
    # Lines of overlap between chunks for context
    DEFAULT_OVERLAP = 50

    def __init__(self, chunk_size: int = DEFAULT_CHUNK_SIZE, overlap: int = DEFAULT_OVERLAP):
        """Initialize chunker.

        Args:
            chunk_size: Number of lines per chunk
            overlap: Number of overlapping lines between chunks
        """
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk(self, content: str) -> List[str]:
        """Split content into chunks.

        Args:
            content: File content to chunk

        Returns:
            List of content chunks
        """
        if not content or not content.strip():
            return []

        lines = content.split("\n")
        chunks = []
        chunk_index = 0

        while chunk_index * (self.chunk_size - self.overlap) < len(lines):
            start = max(0, chunk_index * (self.chunk_size - self.overlap))
            end = min(len(lines), start + self.chunk_size)

            chunk_lines = lines[start:end]
            chunk_text = "\n".join(chunk_lines)

            if chunk_text.strip():
                chunks.append(chunk_text)

            chunk_index += 1

            # Stop if we've reached the end
            if end >= len(lines):
                break

        return chunks

    def chunk_with_metadata(
        self, content: str
    ) -> List[Tuple[int, str]]:
        """Chunk content and return with chunk indices.

        Args:
            content: File content to chunk

        Returns:
            List of tuples (chunk_index, chunk_content)
        """
        chunks = self.chunk(content)
        return [(i, chunk) for i, chunk in enumerate(chunks)]
