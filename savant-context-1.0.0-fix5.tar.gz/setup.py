#!/usr/bin/env python3
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read version from package
with open("savant_context/__init__.py", "r") as f:
    for line in f:
        if line.startswith("__version__"):
            version = line.split('"')[1]
            break

setup(
    name="savant-context",
    version=version,
    author="Ashabbir",
    author_email="ashabbir@github.com",
    description="Context MCP server with PostgreSQL-based code indexer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ashabbir/context",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Database",
        "Topic :: Software Development",
    ],
    python_requires=">=3.10",
    install_requires=[
        "psycopg[binary]>=3.1.0",
        "click>=8.1.0",
        "pathspec>=0.12.0",
        "pygments>=2.15.0",
    ],
    entry_points={
        "console_scripts": [
            "savant-context=savant_context.cli:main",
        ],
    },
)
