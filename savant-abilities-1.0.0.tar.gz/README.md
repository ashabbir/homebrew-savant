Savant Abilities
================

Filesystem-backed, MCP-powered abilities resolver for AI agents. Defines how agents behave via composable personas and tagged rules. Produces deterministic, auditable prompts at runtime.

Quick Start
-----------

- Install: brew install savant-abilities (after formula is published)
- Init store: savant-abilities init
- Validate: savant-abilities validate
- Resolve: savant-abilities resolve --persona engineer --tags backend,security
- Run MCP: savant-abilities run

Environment
-----------

- Base path (default): ~/.savant/abilities
- Override via env: SAVANT_ABILITIES_DIR=/path/to/dir

MCP Tools
---------

- resolve_abilities: Compose persona + tagged rules (+ repo overlay)
- validate_store: Validate schema, indices, and include graph

