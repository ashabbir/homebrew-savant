from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from importlib import resources as impresources
from typing import Dict, List, Optional, Tuple, Set, Any

import yaml


# Be tolerant of BOM, leading whitespace, and CRLF line endings
FRONTMATTER_RE = re.compile(r"^[\ufeff\s]*---\r?\n(.*?)\r?\n---\r?\n(.*)\Z", re.DOTALL)


@dataclass
class Block:
    id: str
    type: str  # persona | rule | policy | style | repo
    tags: List[str]
    priority: int
    includes: List[str] = field(default_factory=list)
    deprecated: bool = False
    supersedes: Optional[str] = None
    # Optional metadata (primarily for repos)
    name: Optional[str] = None
    aliases: List[str] = field(default_factory=list)
    body: str = ""
    path: Optional[Path] = None


class AbilityStore:
    """Loads and indexes ability blocks from a filesystem directory."""

    def __init__(self, base_path: Path):
        self.base_path = Path(base_path)
        self.blocks_by_id: Dict[str, Block] = {}
        self.ids_by_tag: Dict[str, List[str]] = {}
        self.ids_by_type: Dict[str, List[str]] = {}
        self.include_edges: Dict[str, List[str]] = {}

    def load(self) -> None:
        root = self.base_path / "abilities"
        if not root.exists():
            raise RuntimeError(f"Abilities directory not found: {root}")

        self.blocks_by_id.clear()
        self.ids_by_tag.clear()
        self.ids_by_type.clear()
        self.include_edges.clear()

        # Only load markdown files from known categories
        categories = ["personas", "rules", "policies", "repos"]
        for cat in categories:
            base = root / cat
            if not base.exists():
                continue
            for path in base.rglob("*.md"):
                self._load_file(path)

        # Build include edges
        for bid, blk in self.blocks_by_id.items():
            self.include_edges[bid] = list(blk.includes or [])

        # Validate include graph (DAG)
        self._check_cycles()

    def _load_file(self, path: Path) -> None:
        content = path.read_text(encoding="utf-8")
        m = FRONTMATTER_RE.match(content)
        if not m:
            raise RuntimeError(f"Missing YAML front matter in {path}")
        meta_raw, body = m.group(1), m.group(2)
        meta = yaml.safe_load(meta_raw) or {}

        required = ["id", "type", "tags", "priority"]
        for key in required:
            if key not in meta:
                raise RuntimeError(f"Missing required field '{key}' in {path}")

        bid = str(meta["id"]).strip()
        if bid in self.blocks_by_id:
            raise RuntimeError(f"Duplicate id '{bid}' in {path}")

        btype = str(meta["type"]).strip()
        # Normalize and split tag values; accept scalar or list, split on commas/whitespace; case-insensitive
        raw_tags_any = meta.get("tags")
        tags: List[str] = []
        raw_items: List[str] = []
        if raw_tags_any is None:
            raw_items = []
        elif isinstance(raw_tags_any, str):
            raw_items = [raw_tags_any]
        elif isinstance(raw_tags_any, (list, tuple, set)):
            raw_items = [str(x) for x in list(raw_tags_any)]
        else:
            raw_items = [str(raw_tags_any)]
        for t in raw_items:
            # Split on commas or whitespace; keep hyphens/underscores as part of tag
            parts = re.split(r"[\s,]+", str(t))
            for p in parts:
                p = p.strip()
                if p:
                    tags.append(p.lower())
        priority = int(meta["priority"])  # raises if invalid
        includes = [str(x).strip() for x in (meta.get("includes") or [])]
        deprecated = bool(meta.get("deprecated", False))
        supersedes = meta.get("supersedes")
        name = str(meta.get("name")).strip() if meta.get("name") is not None else None
        aliases = [str(x).strip() for x in (meta.get("aliases") or [])]

        blk = Block(
            id=bid,
            type=btype,
            tags=tags,
            priority=priority,
            includes=includes,
            deprecated=deprecated,
            supersedes=str(supersedes) if supersedes else None,
            name=name,
            aliases=aliases,
            body=body.strip(),
            path=path,
        )

        self.blocks_by_id[bid] = blk
        self.ids_by_type.setdefault(btype, []).append(bid)
        for t in tags:
            self.ids_by_tag.setdefault(t, []).append(bid)

    def get(self, block_id: str) -> Optional[Block]:
        return self.blocks_by_id.get(block_id)

    def find_persona(self, name_or_id: str) -> Optional[Block]:
        # Accept both 'engineer' and 'persona.engineer'
        if name_or_id.startswith("persona."):
            return self.get(name_or_id)
        candidate = f"persona.{name_or_id}"
        return self.get(candidate)

    def blocks_with_tags(self, tags: List[str], allowed_types: Optional[Set[str]] = None) -> List[Tuple[Block, Dict[str, Any]]]:
        """Return blocks that have at least one of the provided tags.

        If allowed_types provided, filter by those types.
        """
        # Normalize query tags (case-insensitive) and prepare fuzzy forms
        qtags_raw = [str(t).strip() for t in (tags or []) if t and str(t).strip()]
        qtags: List[str] = [t.lower() for t in qtags_raw]
        qtags_norm: List[str] = [self._norm_key(t) for t in qtags]

        seen: Set[str] = set()
        result: List[Tuple[Block, Dict[str, Any]]] = []

        # 1) Exact matches via index (fast path)
        for i, tag in enumerate(qtags):
            for bid in self.ids_by_tag.get(tag, []):
                if bid in seen:
                    continue
                blk = self.blocks_by_id[bid]
                if allowed_types and blk.type not in allowed_types:
                    continue
                seen.add(bid)
                detail = {
                    "query_tag": qtags_raw[i],
                    "query_norm": qtags_norm[i],
                    "block_tag": tag,
                    "match_type": "exact",
                    "score": 1.0,
                }
                result.append((blk, detail))

        # 2) Fuzzy set intersection (case-insensitive)
        # Uses normalized keys and difflib ratio; also treats substring relations as strong matches.
        if qtags_norm:
            from difflib import SequenceMatcher

            # Safe, inclusive threshold
            THRESH = 0.72

            for bid, blk in self.blocks_by_id.items():
                if bid in seen:
                    continue
                if allowed_types and blk.type not in allowed_types:
                    continue
                # Normalize block tags
                btags = [t for t in (blk.tags or [])]
                btags_norm = [self._norm_key(t) for t in btags]
                # Any fuzzy intersection qualifies this block
                matched = False
                best_local_score = 0.0
                best_qi = -1
                best_bi = -1
                best_type = ""
                for bi, bt in enumerate(btags_norm):
                    for qi, q in enumerate(qtags_norm):
                        if not bt or not q:
                            continue
                        if bt == q:
                            matched = True
                            best_local_score = 1.0
                            best_qi, best_bi, best_type = qi, bi, "exact"
                            break
                        if bt.startswith(q) or q.startswith(bt):
                            matched = True
                            if 0.94 > best_local_score:
                                best_local_score = 0.94
                                best_qi, best_bi, best_type = qi, bi, "prefix"
                        if (q in bt) or (bt in q):
                            matched = True
                            if 0.9 > best_local_score:
                                best_local_score = 0.9
                                best_qi, best_bi, best_type = qi, bi, "substring"
                        r = SequenceMatcher(None, q, bt).ratio()
                        if r >= THRESH and r > best_local_score:
                            matched = True
                            best_local_score = r
                            best_qi, best_bi, best_type = qi, bi, "fuzzy"
                    if matched and best_local_score >= THRESH:
                        break
                if matched:
                    seen.add(bid)
                    detail = {
                        "query_tag": qtags_raw[best_qi] if 0 <= best_qi < len(qtags_raw) else "",
                        "query_norm": qtags_norm[best_qi] if 0 <= best_qi < len(qtags_norm) else "",
                        "block_tag": btags[best_bi] if 0 <= best_bi < len(btags) else "",
                        "block_norm": btags_norm[best_bi] if 0 <= best_bi < len(btags_norm) else "",
                        "match_type": best_type or "fuzzy",
                        "score": float(best_local_score),
                    }
                    result.append((blk, detail))

        return result

    # -------------- Repo fuzzy matching helpers --------------
    @staticmethod
    def _norm_key(s: str) -> str:
        """Normalize a string for loose matching: lowercase and normalize separators."""
        s = (s or "").strip().lower()
        # Replace spaces/underscores with hyphen and collapse multiples
        s = re.sub(r"[\s_]+", "-", s)
        s = re.sub(r"-+", "-", s)
        return s

    @staticmethod
    def _compact(s: str) -> str:
        """Remove non-alphanumeric characters for compact comparison."""
        return re.sub(r"[^a-z0-9]", "", s or "")

    def _repo_keys(self, blk: Block) -> List[str]:
        keys: List[str] = []
        # id variants
        keys.append(blk.id)
        if blk.id.startswith("repo."):
            keys.append(blk.id[len("repo."):])
        # name and aliases
        if blk.name:
            keys.append(blk.name)
        for a in (blk.aliases or []):
            if a:
                keys.append(a)
        # Normalized variants
        normed: List[str] = []
        for k in list(keys):
            nk = self._norm_key(k)
            if nk not in keys:
                normed.append(nk)
        keys.extend(normed)
        # Compact variants
        compacted: List[str] = []
        for k in list(keys):
            ck = self._compact(self._norm_key(k))
            if ck and ck not in keys:
                compacted.append(ck)
        keys.extend(compacted)
        # Deduplicate preserving order
        seen: Set[str] = set()
        ordered: List[str] = []
        for k in keys:
            if k and k not in seen:
                ordered.append(k)
                seen.add(k)
        return ordered

    def find_repo_fuzzy(self, query: str) -> Tuple[Optional[Block], Optional[Dict[str, Any]]]:
        """Fuzzy match a repo by id, name, or aliases.

        Matching order (scored):
        - Exact normalized match (1.0)
        - Exact compacted match (0.97)
        - Prefix relationship (0.94)
        - difflib ratio otherwise
        Returns the highest score above a safe threshold.
        """
        if not query:
            return None, None
        from difflib import SequenceMatcher

        raw = str(query).strip()
        q_norm = self._norm_key(raw)
        q_comp = self._compact(q_norm)

        best_score = -1.0
        best_blk: Optional[Block] = None
        best_detail: Optional[Dict[str, Any]] = None

        for bid in self.ids_by_type.get("repo", []) or []:
            blk = self.blocks_by_id.get(bid)
            if not blk:
                continue
            keys = self._repo_keys(blk)
            score = 0.0
            for k in keys:
                kn = self._norm_key(k)
                kc = self._compact(kn)
                if q_norm == kn:
                    score = 1.0
                    best_detail = {"method": "exact", "matched_key": k, "query": query, "query_norm": q_norm, "key_norm": kn, "score": 1.0}
                    break
                if q_comp and q_comp == kc:
                    if 0.97 > score:
                        score = 0.97
                        best_detail = {"method": "compact", "matched_key": k, "query": query, "query_norm": q_norm, "key_norm": kn, "score": score}
                if kn.startswith(q_norm) or q_norm.startswith(kn):
                    if 0.94 > score:
                        score = 0.94
                        best_detail = {"method": "prefix", "matched_key": k, "query": query, "query_norm": q_norm, "key_norm": kn, "score": score}
                r = SequenceMatcher(None, q_norm, kn).ratio()
                if r > score:
                    score = r
                    best_detail = {"method": "fuzzy", "matched_key": k, "query": query, "query_norm": q_norm, "key_norm": kn, "score": score}
            if (
                score > best_score or (
                    abs(score - best_score) < 1e-6 and best_blk and (blk.priority > best_blk.priority or (blk.priority == best_blk.priority and blk.id < best_blk.id))
                )
            ):
                best_score = score
                best_blk = blk

        # Threshold to avoid wild mismatches; 0.6 is lenient but safe
        if best_blk and best_score >= 0.6:
            return best_blk, best_detail
        return None, None

    def stats(self) -> Dict[str, int]:
        return {
            "personas": len(self.ids_by_type.get("persona", [])),
            "rules": len(self.ids_by_type.get("rule", [])),
            "policies": len(self.ids_by_type.get("policy", [])),
            "styles": len(self.ids_by_type.get("style", [])),
            "repos": len(self.ids_by_type.get("repo", [])),
        }

    def validate_includes(self, raise_on_error: bool = True) -> bool:
        try:
            self._check_cycles()
            # Ensure all includes resolvable
            for bid, edges in self.include_edges.items():
                for inc in edges:
                    if inc not in self.blocks_by_id:
                        raise RuntimeError(f"Unknown include '{inc}' referenced by '{bid}'")
            return True
        except Exception:
            if raise_on_error:
                raise
            return False

    def validate_all(self) -> None:
        self.validate_includes(raise_on_error=True)
        # Additional validations can be added here as needed

    def _check_cycles(self) -> None:
        visited: Set[str] = set()
        stack: Set[str] = set()

        def dfs(node: str) -> None:
            if node in stack:
                raise RuntimeError(f"Circular include detected at '{node}'")
            if node in visited:
                return
            visited.add(node)
            stack.add(node)
            for child in self.include_edges.get(node, []):
                if child not in self.blocks_by_id:
                    # Missing includes will be validated elsewhere; skip here
                    continue
                dfs(child)
            stack.remove(node)

        for nid in list(self.blocks_by_id.keys()):
            dfs(nid)

    def bootstrap_defaults(self) -> None:
        """Create default directory structure and copy packaged seed files.

        Existing files are preserved (not overwritten).
        """
        root = self.base_path / "abilities"
        # Ensure base directories
        (root / "personas").mkdir(parents=True, exist_ok=True)
        (root / "rules" / "backend").mkdir(parents=True, exist_ok=True)
        (root / "rules" / "frontend").mkdir(parents=True, exist_ok=True)
        (root / "policies").mkdir(parents=True, exist_ok=True)
        (root / "repos").mkdir(parents=True, exist_ok=True)

        # Copy default templates bundled with the package
        defaults_root = impresources.files("savant_abilities") / "defaults"

        def iter_md(tree):
            for entry in tree.iterdir():
                try:
                    is_dir = entry.is_dir()
                except Exception:
                    # Some resource backends may not support is_dir reliably
                    # Try to open to decide
                    try:
                        entry.read_bytes()
                        is_dir = False
                    except Exception:
                        is_dir = True
                if is_dir:
                    yield from iter_md(entry)
                else:
                    if entry.name.endswith(".md"):
                        yield entry

        for entry in iter_md(defaults_root):
            # Compute relative path under defaults/
            rel = entry.relative_to(defaults_root)
            dest = root / Path(str(rel))
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists():
                try:
                    content = entry.read_text(encoding="utf-8")
                except Exception:
                    # Fallback via as_file context if needed
                    from importlib.resources import as_file
                    with as_file(entry) as real_path:
                        content = Path(real_path).read_text(encoding="utf-8")
                self._write(dest, content)

    @staticmethod
    def _write(path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.strip() + "\n", encoding="utf-8")
