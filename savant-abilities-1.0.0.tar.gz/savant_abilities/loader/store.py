from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from importlib import resources as impresources
from typing import Dict, List, Optional, Tuple, Set

import yaml


FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)


@dataclass
class Block:
    id: str
    type: str  # persona | rule | policy | style | repo
    tags: List[str]
    priority: int
    includes: List[str] = field(default_factory=list)
    deprecated: bool = False
    supersedes: Optional[str] = None
    body: str = ""
    path: Optional[Path] = None


class AbilityStore:
    """Loads and indexes ability blocks from a filesystem directory."""

    def __init__(self, base_path: Path):
        self.base_path = Path(base_path)
        self.blocks_by_id: Dict[str, Block] = {}
        self.ids_by_tag: Dict[str, List[str]] = {}
        self.ids_by_type: Dict[str, List[str]] = {}
        self.include_edges: Dict[str, List[str]] = {}

    def load(self) -> None:
        root = self.base_path / "abilities"
        if not root.exists():
            raise RuntimeError(f"Abilities directory not found: {root}")

        self.blocks_by_id.clear()
        self.ids_by_tag.clear()
        self.ids_by_type.clear()
        self.include_edges.clear()

        for path in root.rglob("*.md"):
            self._load_file(path)

        # Build include edges
        for bid, blk in self.blocks_by_id.items():
            self.include_edges[bid] = list(blk.includes or [])

        # Validate include graph (DAG)
        self._check_cycles()

    def _load_file(self, path: Path) -> None:
        content = path.read_text(encoding="utf-8")
        m = FRONTMATTER_RE.match(content)
        if not m:
            raise RuntimeError(f"Missing YAML front matter in {path}")
        meta_raw, body = m.group(1), m.group(2)
        meta = yaml.safe_load(meta_raw) or {}

        required = ["id", "type", "tags", "priority"]
        for key in required:
            if key not in meta:
                raise RuntimeError(f"Missing required field '{key}' in {path}")

        bid = str(meta["id"]).strip()
        if bid in self.blocks_by_id:
            raise RuntimeError(f"Duplicate id '{bid}' in {path}")

        btype = str(meta["type"]).strip()
        tags = [str(t).strip() for t in (meta.get("tags") or [])]
        priority = int(meta["priority"])  # raises if invalid
        includes = [str(x).strip() for x in (meta.get("includes") or [])]
        deprecated = bool(meta.get("deprecated", False))
        supersedes = meta.get("supersedes")

        blk = Block(
            id=bid,
            type=btype,
            tags=tags,
            priority=priority,
            includes=includes,
            deprecated=deprecated,
            supersedes=str(supersedes) if supersedes else None,
            body=body.strip(),
            path=path,
        )

        self.blocks_by_id[bid] = blk
        self.ids_by_type.setdefault(btype, []).append(bid)
        for t in tags:
            self.ids_by_tag.setdefault(t, []).append(bid)

    def get(self, block_id: str) -> Optional[Block]:
        return self.blocks_by_id.get(block_id)

    def find_persona(self, name_or_id: str) -> Optional[Block]:
        # Accept both 'engineer' and 'persona.engineer'
        if name_or_id.startswith("persona."):
            return self.get(name_or_id)
        candidate = f"persona.{name_or_id}"
        return self.get(candidate)

    def blocks_with_tags(self, tags: List[str], allowed_types: Optional[Set[str]] = None) -> List[Block]:
        """Return blocks that have at least one of the provided tags.

        If allowed_types provided, filter by those types.
        """
        seen: Set[str] = set()
        result: List[Block] = []
        for tag in tags:
            for bid in self.ids_by_tag.get(tag, []):
                if bid in seen:
                    continue
                blk = self.blocks_by_id[bid]
                if allowed_types and blk.type not in allowed_types:
                    continue
                seen.add(bid)
                result.append(blk)
        return result

    def stats(self) -> Dict[str, int]:
        return {
            "personas": len(self.ids_by_type.get("persona", [])),
            "rules": len(self.ids_by_type.get("rule", [])),
            "policies": len(self.ids_by_type.get("policy", [])),
            "styles": len(self.ids_by_type.get("style", [])),
            "repos": len(self.ids_by_type.get("repo", [])),
        }

    def validate_includes(self, raise_on_error: bool = True) -> bool:
        try:
            self._check_cycles()
            # Ensure all includes resolvable
            for bid, edges in self.include_edges.items():
                for inc in edges:
                    if inc not in self.blocks_by_id:
                        raise RuntimeError(f"Unknown include '{inc}' referenced by '{bid}'")
            return True
        except Exception:
            if raise_on_error:
                raise
            return False

    def validate_all(self) -> None:
        self.validate_includes(raise_on_error=True)
        # Additional validations can be added here as needed

    def _check_cycles(self) -> None:
        visited: Set[str] = set()
        stack: Set[str] = set()

        def dfs(node: str) -> None:
            if node in stack:
                raise RuntimeError(f"Circular include detected at '{node}'")
            if node in visited:
                return
            visited.add(node)
            stack.add(node)
            for child in self.include_edges.get(node, []):
                if child not in self.blocks_by_id:
                    # Missing includes will be validated elsewhere; skip here
                    continue
                dfs(child)
            stack.remove(node)

        for nid in list(self.blocks_by_id.keys()):
            dfs(nid)

    def bootstrap_defaults(self) -> None:
        """Create default directory structure and copy packaged seed files.

        Existing files are preserved (not overwritten).
        """
        root = self.base_path / "abilities"
        # Ensure base directories
        (root / "personas").mkdir(parents=True, exist_ok=True)
        (root / "rules" / "backend").mkdir(parents=True, exist_ok=True)
        (root / "rules" / "frontend").mkdir(parents=True, exist_ok=True)
        (root / "policies").mkdir(parents=True, exist_ok=True)
        (root / "repos").mkdir(parents=True, exist_ok=True)

        # Copy default templates bundled with the package
        defaults_root = impresources.files("savant_abilities") / "defaults"

        def iter_md(tree):
            for entry in tree.iterdir():
                try:
                    is_dir = entry.is_dir()
                except Exception:
                    # Some resource backends may not support is_dir reliably
                    # Try to open to decide
                    try:
                        entry.read_bytes()
                        is_dir = False
                    except Exception:
                        is_dir = True
                if is_dir:
                    yield from iter_md(entry)
                else:
                    if entry.name.endswith(".md"):
                        yield entry

        for entry in iter_md(defaults_root):
            # Compute relative path under defaults/
            rel = entry.relative_to(defaults_root)
            dest = root / Path(str(rel))
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists():
                try:
                    content = entry.read_text(encoding="utf-8")
                except Exception:
                    # Fallback via as_file context if needed
                    from importlib.resources import as_file
                    with as_file(entry) as real_path:
                        content = Path(real_path).read_text(encoding="utf-8")
                self._write(dest, content)

    @staticmethod
    def _write(path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.strip() + "\n", encoding="utf-8")
