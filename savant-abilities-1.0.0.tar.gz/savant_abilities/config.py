from __future__ import annotations

import os
from pathlib import Path


class Config:
    """Configuration for Savant Abilities."""

    # Base directory for abilities store
    BASE_DIR: str = os.environ.get("SAVANT_ABILITIES_DIR", str(Path.home() / ".savant" / "abilities"))

    @staticmethod
    def base_path() -> Path:
        return Path(Config.BASE_DIR).expanduser().resolve()

