---
id: policies.security.no_secrets
type: policy
tags: [security]
priority: 750
includes: []
---
Never commit secrets; use environment variables or a secrets manager.

