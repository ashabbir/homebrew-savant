---
id: policies.security.input_validation
type: policy
tags: [security]
priority: 750
includes: []
---
Validate and sanitize all external inputs.

