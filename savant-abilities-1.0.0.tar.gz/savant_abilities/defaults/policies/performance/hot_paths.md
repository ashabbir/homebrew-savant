---
id: policies.performance.hot_paths
type: policy
tags: [performance, optimization]
priority: 745
includes: []
---
Hot path changes require before/after profiling data.

