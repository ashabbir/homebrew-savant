---
id: policies.style.commits
type: policy
tags: [style, process]
priority: 720
includes: []
---
Commits must be small, scoped, and use clear imperative messages.

