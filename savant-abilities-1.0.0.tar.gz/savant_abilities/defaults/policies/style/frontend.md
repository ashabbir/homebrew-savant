---
id: policies.style.frontend
type: policy
tags: [frontend, style]
priority: 730
includes: []
---
CI must pass ESLint/Prettier with zero warnings.

