---
id: policies.style.backend
type: policy
tags: [backend, style]
priority: 730
includes: []
---
CI must pass format and lint with zero warnings.

