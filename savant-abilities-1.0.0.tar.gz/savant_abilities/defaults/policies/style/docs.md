---
id: policies.style.docs
type: policy
tags: [style, docs]
priority: 720
includes: []
---
Significant changes must include README/ADR updates.

