---
id: policies.testing.flaky
type: policy
tags: [testing]
priority: 740
includes: []
---
Flaky tests must be quarantined or fixed within 24 hours.

