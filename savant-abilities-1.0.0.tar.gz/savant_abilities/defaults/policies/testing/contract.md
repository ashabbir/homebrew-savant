---
id: policies.testing.contract
type: policy
tags: [testing, contract]
priority: 740
includes: []
---
Public APIs must have contract tests for request/response schemas.

