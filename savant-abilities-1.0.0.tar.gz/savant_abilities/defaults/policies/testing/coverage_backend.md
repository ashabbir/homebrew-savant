---
id: policies.testing.coverage_backend
type: policy
tags: [backend, testing, coverage]
priority: 760
includes: []
---
Code coverage (backend) must be >= 85%.

