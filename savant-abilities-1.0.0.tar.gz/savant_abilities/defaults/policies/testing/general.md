---
id: policies.testing.general
type: policy
tags: [testing]
priority: 750
includes: []
---
Every change must include tests for new behavior and fixes.

