---
id: policies.testing.e2e
type: policy
tags: [testing, e2e]
priority: 740
includes: []
---
Critical flows must have E2E coverage in CI.

