---
id: policies.testing.coverage_frontend
type: policy
tags: [frontend, testing, coverage]
priority: 760
includes: []
---
Code coverage (frontend) must be >= 85%.

