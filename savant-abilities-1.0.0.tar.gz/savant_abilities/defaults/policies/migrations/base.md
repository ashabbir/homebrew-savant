---
id: policies.migrations.base
type: policy
tags: [backend, database, migration]
priority: 740
includes: []
---
Migrations must be reversible and idempotent.

