---
id: policies.releases.changelog
type: policy
tags: [release]
priority: 710
includes: []
---
Record notable changes in CHANGELOG for each release.

