---
id: policies.anti_patterns.no_monkey_patch
type: policy
tags: [anti-pattern, ruby]
priority: 720
includes: []
---
Do not monkey patch core or third-party classes.

