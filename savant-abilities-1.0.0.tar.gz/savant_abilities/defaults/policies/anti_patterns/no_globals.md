---
id: policies.anti_patterns.no_globals
type: policy
tags: [anti-pattern, reliability]
priority: 720
includes: []
---
Disallow global mutable state in shared modules.

