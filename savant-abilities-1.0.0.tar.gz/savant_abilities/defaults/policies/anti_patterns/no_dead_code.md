---
id: policies.anti_patterns.no_dead_code
type: policy
tags: [anti-pattern]
priority: 720
includes: []
---
Remove unused code and feature flags promptly.

