---
id: policies.anti_patterns.no_nplus1
type: policy
tags: [anti-pattern, performance]
priority: 720
includes: []
---
N+1 queries must be eliminated before merging.

