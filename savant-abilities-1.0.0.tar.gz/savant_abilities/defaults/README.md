Savant Abilities Store

Place personas, rules, policies, and repo overlays under this directory.
All .md files with YAML front matter are auto-loaded at runtime.

Structure
- personas/
- rules/
- policies/
- repos/

