from __future__ import annotations

import hashlib
from typing import Any, Dict, List, Optional, Set, Tuple

from ..loader.store import AbilityStore, Block


TYPE_ORDER = {
    "persona": 0,
    "repo": 1,
    "rule": 2,
    "policy": 3,
    "style": 4,
}


class Resolver:
    def __init__(self, store: AbilityStore):
        self.store = store

    def resolve_abilities(self, persona: str, tags: List[str], repo_id: Optional[str] = None, include_trace: bool = False) -> Dict[str, Any]:
        persona_block = self.store.find_persona(persona)
        if not persona_block:
            raise RuntimeError(f"Unknown persona: {persona}")

        # Collect sets
        selected: Dict[str, Block] = {}
        trace: List[Dict[str, Any]] = []

        def add_block(b: Block, reason: str) -> None:
            prev = selected.get(b.id)
            if not prev or b.priority > prev.priority or (b.priority == prev.priority and b.id < prev.id):
                selected[b.id] = b
            trace.append({"id": b.id, "type": b.type, "priority": b.priority, "reason": reason})

        # 1) Persona
        add_block(persona_block, "persona")

        # 2) Persona includes (recursive)
        self._expand_includes(persona_block, add_block)

        # 3) Rules matching tags (and policies/styles)
        allowed_types: Set[str] = {"rule", "policy", "style"}
        matched = self.store.blocks_with_tags(tags, allowed_types=allowed_types) if tags else []
        for blk in matched:
            add_block(blk, f"tag-match:{','.join(tags)}")
            self._expand_includes(blk, add_block)

        # 4) Repo overlay (optional)
        repo_block = None
        if repo_id:
            repo_block = self.store.get(f"repo.{repo_id}") or self.store.get(repo_id)
            if repo_block and repo_block.type != "repo":
                # Enforce type
                repo_block = None
            if repo_block:
                add_block(repo_block, f"repo:{repo_id}")
                self._expand_includes(repo_block, add_block)

        # Deduplicate and order deterministically
        ordered = sorted(
            selected.values(),
            key=lambda b: (-b.priority, TYPE_ORDER.get(b.type, 99), b.id),
        )

        # Render prompt by sections
        persona_section = self._render_section("Persona", [persona_block])
        repo_section = self._render_section("Repo Constraints", [repo_block] if repo_block else [])
        # Collect rules/policies/style excluding persona and repo
        others: List[Block] = [b for b in ordered if b.id not in {persona_block.id, repo_block.id if repo_block else ""}]
        # Break into groups by type
        rules = [b for b in others if b.type == "rule"]
        policies = [b for b in others if b.type in {"policy", "style"}]
        rules_section = self._render_section("Rules", rules)
        policies_section = self._render_section("Policies & Style", policies)

        prompt = "\n\n".join([s for s in [persona_section, repo_section, rules_section, policies_section] if s])

        applied = {
            "persona": persona_block.id,
            "rules": [b.id for b in rules],
            **({"repo": repo_block.id} if repo_block else {}),
        }

        manifest = {
            "applied": applied,
            "order": [b.id for b in ordered],
            "hash": hashlib.sha256((prompt + "\n" + ",".join(applied.get("rules", []))).encode("utf-8")).hexdigest(),
        }

        resp: Dict[str, Any] = {
            "applied": applied,
            "prompt": prompt,
            "manifest": manifest,
        }
        if include_trace:
            resp["trace"] = trace
        return resp

    def _expand_includes(self, blk: Block, add) -> None:
        for inc_id in blk.includes or []:
            inc = self.store.get(inc_id)
            if not inc:
                raise RuntimeError(f"Unknown include '{inc_id}' in {blk.id}")
            add(inc, f"include:{blk.id}")
            self._expand_includes(inc, add)

    @staticmethod
    def _render_section(title: str, blocks: List[Block]) -> str:
        if not blocks:
            return ""
        parts: List[str] = [f"# {title}"]
        for b in blocks:
            parts.append(f"<!-- {b.id} (priority {b.priority}) -->\n{b.body}".strip())
        return "\n\n".join(parts).strip()

