"""CLI for savant-abilities."""

import json
import logging
import sys
from pathlib import Path
from typing import Optional, List

import click

from . import __version__
from .config import Config
from .loader.store import AbilityStore
from .resolver.engine import Resolver
from .mcp.server import MCPServer

# Configure logging to stderr only (keep stdout clean for MCP)
logging.basicConfig(
    level=logging.ERROR,
    format="%(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)


# ASCII Art banner (same style as context)
BANNER = """
  ███████╗ █████╗ ██╗   ██╗ █████╗ ███╗   ██╗████████╗
  ██╔════╝██╔══██╗██║   ██║██╔══██╗████╗  ██║╚══██╔══╝
  ███████╗███████║██║   ██║███████║██╔██╗ ██║   ██║   
  ╚════██║██╔══██║╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║   
  ███████║██║  ██║ ╚████╔╝ ██║  ██║██║ ╚████║   ██║   
  ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   

 Savant Abilities - MCP Server for Persona & Rule Resolution
 By AmdSh
 Project 🅧
 Version: {version}
  Base Path: {base}
  Blocks: {blocks}
  Includes: {includes}

 ═══════════════════════════════════════════════════════════════════════════════
"""


def print_banner(store: Optional[AbilityStore] = None) -> None:
    """Print the ASCII art banner with environment info."""
    base = Config.base_path()
    blocks = "unknown"
    includes = "unknown"

    try:
        store = store or AbilityStore(base)
        store.load()
        stats = store.stats()
        blocks = (
            f"personas={stats['personas']}, rules={stats['rules']}, policies={stats['policies']}, styles={stats['styles']}, repos={stats['repos']}"
        )
        includes = "ok" if store.validate_includes(raise_on_error=False) else "invalid"
    except Exception:
        # Best effort; banner should never crash
        pass

    click.echo(
        BANNER.format(
            version=__version__,
            base=str(base),
            blocks=blocks,
            includes=includes,
        )
    )


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="savant-abilities")
@click.pass_context
def main(ctx) -> None:
    """Savant Abilities - Filesystem-backed abilities resolver and MCP server."""
    # Skip banner for pure-output commands
    pure_output = {"run", "tool"}
    if ctx.invoked_subcommand not in pure_output:
        print_banner()
    if ctx.invoked_subcommand is None:
        # No default action
        pass


@main.command()
def run() -> None:
    """Start the MCP server (stdio)."""
    # MCP must output ONLY JSON-RPC on stdout
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        server = MCPServer(store)
        server.run()
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        raise click.Abort()


@main.command()
@click.option("--dir", "base_dir", type=click.Path(file_okay=False, dir_okay=True, path_type=Path), help="Base abilities directory (default: ~/.savant/abilities)")
def init(base_dir: Optional[Path]) -> None:
    """Bootstrap abilities directory with defaults."""
    base = base_dir or Config.base_path()
    store = AbilityStore(base)
    if base.exists() and any(base.iterdir()):
        if not click.confirm(f"Directory {base} is not empty. Continue and add defaults?"):
            click.echo("Aborted")
            return
    store.bootstrap_defaults()
    click.echo(f"✓ Initialized abilities at {base}")


@main.command()
def validate() -> None:
    """Validate schema, indices, and include graph."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        store.validate_all()
        click.echo("✓ Abilities store is valid")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
@click.option("--persona", required=True, help="Persona id or name (e.g., engineer or persona.engineer)")
@click.option("--tags", default="", help="Comma-separated tags (e.g., backend,security)")
@click.option("--repo-id", default=None, help="Optional repo overlay id (e.g., sales-enablement)")
@click.option("--json", "json_out", is_flag=True, help="Output full JSON response instead of prompt only")
@click.option("--trace/--no-trace", default=False, help="Include resolution trace in JSON output")
def resolve(persona: str, tags: str, repo_id: Optional[str], json_out: bool, trace: bool) -> None:
    """Resolve abilities and render prompt deterministically."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        resolver = Resolver(store)
        tag_list: List[str] = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        result = resolver.resolve_abilities(persona=persona, tags=tag_list, repo_id=repo_id, include_trace=trace)
        if json_out:
            applied = result.get("applied") or {}
            manifest = result.get("manifest") or {}
            order = manifest.get("order") or []
            # persona body text
            persona_id = applied.get("persona")
            persona_body = ""
            if persona_id and persona_id in store.blocks_by_id:
                persona_body = store.blocks_by_id[persona_id].body
            # Expand rule/policy IDs to their body text for convenience
            rule_ids = applied.get("rules", [])
            policy_ids = applied.get("policies", [])
            repo_id_applied = applied.get("repo", "")
            rule_bodies = [(store.blocks_by_id.get(r).body if r in store.blocks_by_id else r) for r in rule_ids]
            policy_bodies = [(store.blocks_by_id.get(p).body if p in store.blocks_by_id else p) for p in policy_ids]
            repo_body = store.blocks_by_id.get(repo_id_applied).body if (repo_id_applied and repo_id_applied in store.blocks_by_id) else ""
            shaped = {
                "persona": persona_body,
                "repo": repo_body,
                "rules": rule_bodies,
                "policies": policy_bodies,
                "manifest": {
                    "applied": {
                        "persona": applied.get("persona", ""),
                        "repo": applied.get("repo", ""),
                        "rules": rule_ids,
                        "policies": policy_ids,
                    },
                    "order": order,
                    "hash": (manifest.get("hash") or ""),
                },
            }
            # Attach trace when requested
            if trace:
                shaped["trace"] = result.get("trace", [])
            click.echo(json.dumps(shaped, indent=2))
        else:
            click.echo(result.get("prompt", ""))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show counts of loaded blocks and base path.""" 
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        stats = store.stats()
        click.echo(f"Base: {Config.base_path()}")
        click.echo(f"Blocks: {json.dumps(stats)}")
        click.echo("Includes: ok" if store.validate_includes(raise_on_error=False) else "Includes: invalid")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.group()
def tool() -> None:
    """Call MCP tools directly from CLI (JSON output)."""
    pass


@tool.command(name="resolve_abilities")
@click.option("--persona", required=True, help="Persona id or name (e.g., engineer)")
@click.option("--tags", default="", help="Comma-separated tags (e.g., backend,security)")
@click.option("--repo-id", default=None, help="Optional repo overlay id")
@click.option("--trace/--no-trace", default=False, help="Include resolution trace in JSON output")
def tool_resolve_abilities(persona: str, tags: str, repo_id: Optional[str], trace: bool) -> None:
    """Resolve abilities and emit JSON (shaped output)."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        resolver = Resolver(store)
        tag_list: List[str] = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        result = resolver.resolve_abilities(persona=persona, tags=tag_list, repo_id=repo_id, include_trace=trace)
        applied = result.get("applied") or {}
        manifest = result.get("manifest") or {}
        order = manifest.get("order") or []
        # persona body text
        persona_id = applied.get("persona")
        persona_body = ""
        if persona_id and persona_id in store.blocks_by_id:
            persona_body = store.blocks_by_id[persona_id].body
        # Expand rule/policy IDs to their body text for convenience
        rule_ids = applied.get("rules", [])
        policy_ids = applied.get("policies", [])
        repo_id_applied = applied.get("repo", "")
        rule_bodies = [(store.blocks_by_id.get(r).body if r in store.blocks_by_id else r) for r in rule_ids]
        policy_bodies = [(store.blocks_by_id.get(p).body if p in store.blocks_by_id else p) for p in policy_ids]
        repo_body = store.blocks_by_id.get(repo_id_applied).body if (repo_id_applied and repo_id_applied in store.blocks_by_id) else ""
        shaped = {
            "persona": persona_body,
            "repo": repo_body,
            "rules": rule_bodies,
            "policies": policy_bodies,
            "manifest": {
                "applied": {
                    "persona": applied.get("persona", ""),
                    "repo": applied.get("repo", ""),
                    "rules": rule_ids,
                    "policies": policy_ids,
                },
                "order": order,
                "hash": (manifest.get("hash") or ""),
            },
        }
        if trace:
            shaped["trace"] = result.get("trace", [])
        click.echo(json.dumps(shaped, indent=2))
    except Exception as e:
        click.echo(json.dumps({"error": str(e)}))


@tool.command(name="list_personas")
def tool_list_personas() -> None:
    """List available personas (name and path)."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        from .mcp.tools import ToolHandler
        items = ToolHandler(store).list_personas()
        click.echo(json.dumps(items, indent=2))
    except Exception as e:
        click.echo(json.dumps({"error": str(e)}))


@tool.command(name="list_repos")
def tool_list_repos() -> None:
    """List available repos (name and path)."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        from .mcp.tools import ToolHandler
        items = ToolHandler(store).list_repos()
        click.echo(json.dumps(items, indent=2))
    except Exception as e:
        click.echo(json.dumps({"error": str(e)}))


@tool.command(name="list_rules")
def tool_list_rules() -> None:
    """List available rules (name and path)."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        from .mcp.tools import ToolHandler
        items = ToolHandler(store).list_rules()
        click.echo(json.dumps(items, indent=2))
    except Exception as e:
        click.echo(json.dumps({"error": str(e)}))


@tool.command(name="list_policies")
def tool_list_policies() -> None:
    """List available policies and styles (name and path)."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        from .mcp.tools import ToolHandler
        items = ToolHandler(store).list_policies()
        click.echo(json.dumps(items, indent=2))
    except Exception as e:
        click.echo(json.dumps({"error": str(e)}))


@tool.command(name="validate_store")
def tool_validate_store() -> None:
    """Validate abilities store and emit JSON result."""
    store = AbilityStore(Config.base_path())
    try:
        store.load()
        store.validate_all()
        click.echo(json.dumps({"ok": True, "stats": store.stats()}, indent=2))
    except Exception as e:
        click.echo(json.dumps({"ok": False, "error": str(e)}))
