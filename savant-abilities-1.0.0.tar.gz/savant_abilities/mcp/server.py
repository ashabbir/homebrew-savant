"""MCP (Model Context Protocol) server for Savant Abilities."""

import json
import logging
import sys
from datetime import datetime
from typing import Any, Dict

from ..loader.store import AbilityStore
from .tools import ToolHandler, get_tool_definitions

logger = logging.getLogger(__name__)


class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


class MCPServer:
    def __init__(self, store: AbilityStore):
        self.store = store
        self.tool_handler = ToolHandler(store)

    def run(self) -> None:
        logger.debug("Abilities MCP server waiting for JSON-RPC 2.0 requests")
        try:
            while True:
                try:
                    line = input()
                    if not line.strip():
                        continue
                    request = json.loads(line)
                    if not isinstance(request, dict):
                        continue
                    jsonrpc = request.get("jsonrpc")
                    method = request.get("method")
                    params = request.get("params", {})
                    req_id = request.get("id")

                    if jsonrpc != "2.0":
                        if req_id is not None:
                            self._send_error(-32600, "Invalid Request: jsonrpc must be 2.0", req_id)
                        continue
                    if not method:
                        if req_id is not None:
                            self._send_error(-32600, "Invalid Request: method is required", req_id)
                        continue

                    if method == "initialize":
                        result = {
                            "protocolVersion": "2024-11-05",
                            "capabilities": {"tools": {"list": {}, "call": {}}},
                            "serverInfo": {"name": "savant-abilities", "version": "1.0.0"},
                        }
                    elif method == "tools/list":
                        result = {"tools": get_tool_definitions()}
                    elif method == "tools/call":
                        tool_name = params.get("name")
                        tool_args = params.get("arguments", {})
                        tool_result = self._call_tool(tool_name, tool_args)
                        result = self._wrap_tool_result(tool_result)
                    else:
                        self._send_error(-32601, f"Method not found: {method}", req_id)
                        continue

                    self._send_response(result, req_id)
                except EOFError:
                    logger.debug("MCP server connection closed (EOF on stdin)")
                    break
                except json.JSONDecodeError as e:
                    self._send_error(-32700, f"Parse error: {e}", None)
                except Exception as e:
                    logger.error(f"Request processing failed: {e}")
                    self._send_error(-32603, f"Internal error: {e}", req_id if 'req_id' in locals() else None)
        except KeyboardInterrupt:
            logger.debug("MCP server shutting down...")

    def _send_response(self, result: Any, req_id: Any) -> None:
        response = {"jsonrpc": "2.0", "result": result, "id": req_id}
        print(json.dumps(response, cls=DateTimeEncoder))
        sys.stdout.flush()

    def _send_error(self, code: int, message: str, req_id: Any) -> None:
        if req_id is None:
            return
        response = {"jsonrpc": "2.0", "error": {"code": code, "message": message}, "id": req_id}
        print(json.dumps(response, cls=DateTimeEncoder))
        sys.stdout.flush()

    def _call_tool(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if tool_name == "resolve_abilities":
            return self.tool_handler.resolve_abilities(
                persona=args.get("persona", ""),
                tags=args.get("tags", []),
                repo_id=args.get("repo_id"),
            )
        elif tool_name == "validate_store":
            return self.tool_handler.validate_store()
        else:
            return {"error": f"Unknown tool: {tool_name}"}

    def _wrap_tool_result(self, data: Any) -> Dict[str, Any]:
        is_error = isinstance(data, dict) and "error" in data
        json_text = json.dumps(data, cls=DateTimeEncoder)
        return {
            "content": [{"type": "text", "text": json_text}],
            **({"isError": True} if is_error else {}),
        }

