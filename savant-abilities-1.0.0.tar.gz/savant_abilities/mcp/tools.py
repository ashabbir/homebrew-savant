"""MCP tool implementations for Savant Abilities."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from ..loader.store import AbilityStore
from ..resolver.engine import Resolver

logger = logging.getLogger(__name__)


class ToolHandler:
    def __init__(self, store: AbilityStore):
        self.store = store
        self.resolver = Resolver(store)

    def resolve_abilities(self, persona: str, tags: List[str], repo_id: Optional[str] = None, trace: bool = False) -> Dict[str, Any]:
        try:
            if not persona:
                return {"error": "persona required"}
            # Ensure store loaded (idempotent safe)
            if not self.store.blocks_by_id:
                self.store.load()
            result = self.resolver.resolve_abilities(persona=persona, tags=tags or [], repo_id=repo_id, include_trace=trace)
            # Shape output per requested contract
            applied = result.get("applied") or {}
            manifest = result.get("manifest") or {}
            order = manifest.get("order") or []
            # Resolve persona body text
            persona_id = applied.get("persona")
            persona_body = ""
            if persona_id and persona_id in self.store.blocks_by_id:
                persona_body = self.store.blocks_by_id[persona_id].body

            # Expand rules and policies to their body text for easy consumption
            rule_ids = applied.get("rules", [])
            policy_ids = applied.get("policies", [])
            repo_id = applied.get("repo", "")

            rule_bodies: List[str] = []
            for rid in rule_ids:
                blk = self.store.blocks_by_id.get(rid)
                rule_bodies.append(blk.body if blk else rid)

            policy_bodies: List[str] = []
            for pid in policy_ids:
                blk = self.store.blocks_by_id.get(pid)
                policy_bodies.append(blk.body if blk else pid)

            # Repo body text (if any)
            repo_body = ""
            if repo_id and repo_id in self.store.blocks_by_id:
                repo_body = self.store.blocks_by_id[repo_id].body

            shaped = {
                "persona": persona_body,
                "repo": repo_body,
                "rules": rule_bodies,
                "policies": policy_bodies,
                "manifest": {
                    "applied": {
                        "persona": applied.get("persona", ""),
                        "repo": applied.get("repo", ""),
                        "rules": rule_ids,
                        "policies": policy_ids,
                    },
                    "order": order,
                    "hash": (manifest.get("hash") or ""),
                },
            }
            # Attach resolution trace if requested
            if trace:
                shaped["trace"] = result.get("trace", [])
            return shaped
        except Exception as e:
            logger.error(f"resolve_abilities failed: {e}")
            return {"error": str(e)}

    def validate_store(self) -> Dict[str, Any]:
        try:
            # Ensure store loaded (idempotent safe)
            if not self.store.blocks_by_id:
                self.store.load()
            self.store.validate_all()
            stats = self.store.stats()
            return {"ok": True, "stats": stats}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def get_tool_definitions() -> List[Dict[str, Any]]:
    return [
        {
            "name": "resolve_abilities",
            "description": "Resolve persona + tagged rules (+ optional repo overlay) into a deterministic prompt",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "persona": {"type": "string", "description": "Persona id or name (e.g., engineer or persona.engineer)"},
                    "tags": {"type": "array", "items": {"type": "string"}, "description": "List of tags (e.g., backend,security)"},
                    "repo_id": {"type": ["string", "null"], "description": "Optional repo overlay id (e.g., sales-enablement)"},
                    "trace": {"type": ["boolean", "null"], "description": "Include resolution trace for debugging (default false)"},
                },
                "required": ["persona"],
            },
        },
        {
            "name": "validate_store",
            "description": "Validate abilities store (schema and include graph)",
            "inputSchema": {"type": "object", "properties": {}},
        },
    ]
