# Savant Context - Agent Integration & Development Guide

## Quick Start for Agents (Claude, Cline, etc.)

### MCP Server Compliance (JSON-RPC 2.0)

The `savant-context run` command starts a **100% JSON-RPC 2.0 compliant** MCP server on stdio.

**Critical Requirements:**
- ✅ Only JSON-RPC 2.0 messages on **stdout**
- ✅ No banner, no startup messages on stdout
- ✅ All diagnostics go to **stderr**
- ✅ Proper request format: `{"jsonrpc": "2.0", "method": "...", "params": {...}, "id": ...}`
- ✅ Proper response format: `{"jsonrpc": "2.0", "result": {...}, "id": ...}`

### Available Methods (JSON-RPC 2.0)

```json
{
  "jsonrpc": "2.0",
  "method": "code_search",
  "params": {
    "query": "function_name",
    "repo": "optional_repo_name",
    "limit": 10
  },
  "id": 1
}
```

**Available Methods:**
1. `code_search` - Semantic search across indexed code
   - Params: `query` (required), `repo` (optional), `limit` (default: 10, max: 100)

2. `memory_bank_search` - Search memory bank markdown
   - Params: `query` (required), `repo` (optional), `limit` (default: 20)

3. `memory_resources_list` - List memory bank resources
   - Params: `repo` (optional)

4. `memory_resources_read` - Read resource by URI
   - Params: `uri` (required)

5. `repos_list` - List indexed repos with README excerpts
   - Params: `filter` (optional), `max_length` (default: 4096)

6. `repo_status` - Show per-repo index status
   - Params: none

### Response Format (Always JSON-RPC 2.0)

**Success Response:**
```json
{
  "jsonrpc": "2.0",
  "result": {
    "query": "search_term",
    "result_count": 5,
    "results": [...]
  },
  "id": 1
}
```

**Error Response:**
```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32601,
    "message": "Method not found"
  },
  "id": 1
}
```

---

## Local Development & Installation

### Prerequisites

- macOS (arm64)
- Python 3.10+
- PostgreSQL 15
- Homebrew (for easy installation)

### Development Setup

1. **Clone and Install**
```bash
git clone https://github.com/ashabbir/context.git
cd context
/opt/homebrew/bin/python3.10 -m pip install -e .
```

2. **Initialize Database**
```bash
savant-context db setup
```

3. **Index a Repository**
```bash
savant-context index repo /path/to/your/repo
```

4. **Start MCP Server (for agent integration)**
```bash
savant-context run
```

### Testing the Server

**Option 1: With echo (one request)**
```bash
echo '{"jsonrpc": "2.0", "method": "repo_status", "params": {}, "id": 1}' | \
  savant-context run 2>/dev/null
```

**Option 2: Interactive testing with Cline**
- Add to `.cursor/tools.json` or Cline config:
```json
{
  "server": "savant-context run",
  "type": "stdio"
}
```

**Option 3: Direct CLI tool invocation (not MCP)**
```bash
# These output JSON but skip the MCP server format
savant-context tool code_search "function_name" --limit 5
savant-context tool repos_list
savant-context tool repo_status
```

---

## Publishing & Distribution

### Release Process

1. **Update Version**
   - Edit `/Users/home/code/context/savant_context/__init__.py`
   - Change `__version__ = "1.0.0"` to new version

2. **Build Distribution Tarball**
```bash
cd /Users/home/code
rm -rf context/.git context/__pycache__
tar -czf /tmp/savant-context-1.0.0.tar.gz \
  --exclude='.git' --exclude='__pycache__' \
  --exclude='*.pyc' --exclude='.pytest_cache' \
  --exclude='build' --exclude='dist' \
  context
shasum -a 256 /tmp/savant-context-1.0.0.tar.gz
```

3. **Update Homebrew Formula**
   - Edit `/Users/home/code/homebrew-savant/Formula/savant-context.rb`
   - Update SHA256 hash from step 2
   - Copy tarball to tap repo:
```bash
cp /tmp/savant-context-1.0.0.tar.gz /Users/home/code/homebrew-savant/
cd /Users/home/code/homebrew-savant
git add -A
git commit -m "Release v1.0.0"
git push origin main
```

4. **Publish to Homebrew**
```bash
cd /Users/home/code/homebrew-savant
git add Formula/savant-context.rb
git commit -m "v1.0.0 - description of changes"
git push
```

### Installation Methods

**Option 1: Homebrew (Recommended)**
```bash
brew tap ashabbir/savant https://github.com/ashabbir/homebrew-savant
brew install savant-context
```

**Option 2: From Source**
```bash
git clone https://github.com/ashabbir/context.git
cd context
/opt/homebrew/bin/python3.10 -m pip install .
savant-context --version
```

**Option 3: Pip (Direct)**
```bash
/opt/homebrew/bin/python3.10 -m pip install git+https://github.com/ashabbir/context.git
```

---

## Architecture & Key Files

### Core Components

**CLI Entry Point**
- `savant_context/cli.py` - All CLI commands
- Commands skip banner output for MCP server (`run`) and JSON tools (`tool`)

**MCP Server (JSON-RPC 2.0)**
- `savant_context/mcp/server.py` - JSON-RPC 2.0 server
  - `DateTimeEncoder` - Handles datetime serialization
  - `_send_response()` - Sends success responses
  - `_send_error()` - Sends error responses with proper error codes

**Tool Implementation**
- `savant_context/mcp/tools.py` - All 6 tool handlers
- Tools return clean JSON with no extra output

**Database**
- `savant_context/db/client.py` - PostgreSQL connection management
- `savant_context/db/schema.py` - Database schema with pgvector embeddings
- Uses pgvector (ivfflat cosine) for semantic vector search

**Indexing**
- `savant_context/indexer/indexer.py` - Repository indexing coordinator
- `savant_context/indexer/walker.py` - File system traversal with .gitignore support
- Auto-detects and skips non-human-written files (.pyc, .min.js, .pb.go, etc.)

### Configuration

**Environment Variables:**
```bash
POSTGRES_HOST=localhost           # Default: localhost
POSTGRES_PORT=5432               # Default: 5432
POSTGRES_DB=savant-context-standalone  # Default: savant-context-standalone
POSTGRES_USER=$USER               # Default: current user
POSTGRES_PASSWORD=               # Optional
```

**Logging:**
- All errors go to stderr
- MCP server (running `savant-context run`) outputs ONLY JSON-RPC to stdout
- No diagnostic messages pollute JSON output

---

## Troubleshooting

### MCP Server Not Producing Output

**Problem:** `savant-context run` seems to hang
**Solution:**
- Server is waiting for input on stdin
- Send JSON-RPC 2.0 formatted request
- Server will respond on stdout

### Database Connection Issues

**Problem:** "Error: Failed to connect to database"
**Solution:**
```bash
# Ensure PostgreSQL is running
brew services list | grep postgres

# If not running:
brew services start postgresql@15

# Check database exists
psql -l | grep savant
```

### Invalid JSON Output

**Problem:** "not valid JSON" errors
**Solution:**
- Ensure you're using `savant-context run` (MCP mode)
- NOT `savant-context tool code_search` (CLI mode - different format)
- Check request uses proper JSON-RPC 2.0 format with `jsonrpc`, `method`, `params`, `id`

---

## Development Notes

### Adding New Tools

1. Implement method in `savant_context/mcp/tools.py`
2. Add dispatch case in `savant_context/mcp/server.py` (line ~80)
3. Tool must return dict (will be JSON serialized)
4. All output via stdout must be JSON-RPC 2.0 only

### Modifying CLI Commands

1. Edit `savant_context/cli.py`
2. Add/remove commands using `@main.command()`
3. For tools that need clean output, add to `pure_output_commands` set (line ~87)
4. Test: `savant-context command_name`

### Database Changes

1. Edit `savant_context/db/schema.py`
2. Run `savant-context db setup` to reinit (WARNING: clears data)
3. Or use migrations (TODO: implement migration system)

---

## Version History

### v1.0.0 (Current)
- ✅ 100% JSON-RPC 2.0 compliant MCP server
- ✅ 6 core tools: code_search, memory_bank_search, memory_resources_list, memory_resources_read, repos_list, repo_status
- ✅ PostgreSQL semantic vector search with pgvector (ivfflat)
- ✅ Automatic non-human-file detection
- ✅ Homebrew distribution
- ✅ Clean stdout for MCP (no banners, no logs)

---

## Repository Structure

```
context/                                     # Main code repository
├── savant_context/
│   ├── __init__.py                        # Version: 1.0.0
│   ├── cli.py                             # CLI entry point (banner-skipped for run/tool)
│   ├── config.py                          # Environment configuration
│   ├── db/                                # Database layer
│   │   ├── client.py                      # PostgreSQL client
│   │   ├── schema.py                      # Schema with FTS
│   │   └── operations.py                  # Backup/restore
│   ├── indexer/                           # Code indexing
│   │   ├── indexer.py                     # Main indexer
│   │   ├── walker.py                      # File walker (ignores non-human files)
│   │   └── chunker.py                     # Content chunking
│   └── mcp/                               # MCP server (JSON-RPC 2.0)
│       ├── server.py                      # Server with DateTimeEncoder
│       └── tools.py                       # 6 tools implementation
├── setup.py                               # Entry points for CLI
├── pyproject.toml                         # Package metadata
├── README.md                              # User documentation
├── AGENT.md                               # This file
└── LICENSE                                # MIT License

homebrew-savant/                          # Public Homebrew tap
├── Formula/
│   └── savant-context.rb                  # Brew formula
└── savant-context-1.0.0.tar.gz           # Distribution tarball
```

---

## Quick Commands

```bash
# Development
pip install -e /Users/home/code/context

# Database
savant-context db setup                    # Initialize
savant-context db destroy                  # Clear all data (WARNING)
savant-context psql                        # Direct access to database

# Indexing
savant-context index repo /path/to/repo    # Index repository
savant-context status                      # Show indexed repos

# MCP Server (for agents like Cline)
savant-context run                         # Start JSON-RPC 2.0 server

# CLI Tools (direct invocation, NOT MCP)
savant-context tool code_search "query"
savant-context tool repos_list
savant-context tool repo_status

# Help
savant-context --help
savant-context --version
```
