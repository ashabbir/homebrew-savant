"""Dependency helpers for a smoother out-of-the-box experience.

This module provides best-effort installation of optional ML dependencies
when they are missing at runtime (e.g., sentence-transformers, torch).

It favors a pragmatic approach: install into the environment used to run
the CLI (sys.executable -m pip), print concise progress messages to stderr,
and fall back to actionable guidance if installation fails.
"""

from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from typing import Iterable


def _have_module(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def _pip_install(pkgs: Iterable[str]) -> None:
    # Minimal, quiet-ish install into the current interpreter's environment.
    # Avoid raising on non-zero until after execution; surfacing stderr is handled by caller.
    args = [sys.executable, "-m", "pip", "install", "--upgrade", "--ignore-installed"]
    args.extend(list(pkgs))
    # Stream output so users see progress when it takes a while.
    subprocess.run(args, check=True)


def ensure_transformer_deps(auto_install: bool = True) -> None:
    """Ensure core transformer stack is importable.

    Attempts to install minimal required packages if missing and auto_install=True.
    Raises ImportError/RuntimeError with actionable guidance on failure.
    """
    if _have_module("sentence_transformers"):
        # Validate compatibility with installed huggingface_hub; upgrade ST if needed.
        try:
            import importlib
            from packaging.version import Version
            st = importlib.import_module("sentence_transformers")
            hf = importlib.import_module("huggingface_hub")
            st_ver = Version(getattr(st, "__version__", "0"))
            hf_ver = Version(getattr(hf, "__version__", "0"))
            # huggingface_hub >= 0.34.0 removed cached_download API used by ST < 5
            if hf_ver >= Version("0.34.0") and st_ver < Version("5.0.0") and auto_install:
                _pip_install(["sentence-transformers>=5.0.0"])  # noqa: S603,S607
        except Exception:
            # Best-effort; fall back to normal import path below
            pass
        return

    if not auto_install:
        raise RuntimeError(
            "sentence-transformers is required but not installed. "
            "Re-run: python -m pip install 'sentence-transformers>=2.2.2' 'torch>=2.0.0'"
        )

    # Try installation in two passes to minimize conflicts.
    # 1) torch first (large wheel), then the rest.
    try:
        # Prefer CPU wheels; let pip resolve platform-specific build.
        _pip_install(["torch>=2.0.0"])  # noqa: S603,S607
    except Exception as e:
        raise RuntimeError(
            f"Failed to install torch automatically: {e}.\n"
            "Try: python -m pip install 'torch>=2.0.0'"
        ) from e

    try:
        _pip_install([
            # Newer ST avoids deprecated APIs in huggingface_hub
            "sentence-transformers>=5.0.0",
            "transformers>=4.24.0",
            "huggingface_hub>=0.20.0",
            "tokenizers",
            "safetensors",
            "numpy>=1.23.0",
            # Optional but commonly required by ST package namespace
            "nltk",
            "scikit-learn",
            "scipy",
        ])  # noqa: S603,S607
    except Exception as e:
        raise RuntimeError(
            f"Failed to install sentence-transformers stack automatically: {e}.\n"
            "Try: python -m pip install 'sentence-transformers>=2.2.2' 'transformers>=4.24.0' tokenizers safetensors"
        ) from e

    # Verify import now works.
    if not _have_module("sentence_transformers"):
        raise RuntimeError(
            "sentence-transformers appears unavailable after installation. "
            "Ensure you're invoking the same interpreter that installed the packages."
        )
